// index.js
// --- Quan trọng: Đoạn code này cần được đặt ở ĐẦU file để giữ bot luôn chạy trên Replit ---
const http = require('http');
const server = http.createServer((req, res) => {
    res.writeHead(200, { 'Content-Type': 'text/plain' });
    res.end('Bot đang hoạt động!\n');
});

const PORT = 3000; // Cổng mặc định của Replit
server.listen(PORT, () => {
    console.log(`Máy chủ web đang chạy trên cổng ${PORT} để giữ bot luôn hoạt động.`);
});
// --- Kết thúc đoạn code giữ bot luôn chạy ---


require('dotenv').config(); // Tải các biến môi trường từ file .env

// Bắt các lỗi không được xử lý để ngăn bot tắt đột ngột
process.on('unhandledRejection', error => {
    console.error('Lỗi Promise không được xử lý:', error);
    if (error.code === 50013) {
        console.error("LỖI: Bot thiếu quyền 'Manage Roles'. Vui lòng cấp quyền này cho bot trên máy chủ Discord.");
    }
});

process.on('uncaughtException', error => {
    console.error('Lỗi không được bắt:', error);
});


const { Client, GatewayIntentBits, Partials, AttachmentBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, ModalBuilder, TextInputBuilder, TextInputStyle } = require('discord.js');
const { initializeApp } = require('firebase/app');
const { getFirestore, doc, getDoc, setDoc, collection, getDocs, updateDoc, writeBatch } = require('firebase/firestore');
const { getAuth, signInAnonymously } = require('firebase/auth');

// Dán vào sau các dòng require(...)
const { GoogleGenerativeAI } = require('@google/generative-ai');

// ✅ THÊM DÒNG NÀY VÀO ĐỂ KIỂM TRA
console.log("Bot đang cố sử dụng API Key:", process.env.GEMINI_API_KEY);

// Khởi tạo Gemini với API Key từ Secrets
const genAI = new GoogleGenerativeAI(process.env.GEMINI_API_KEY);
const model = genAI.getGenerativeModel({ model: "gemini-1.5-flash"});

// --- Cấu hình Firebase ---
let app;
let db;
let auth;

const REPLIT_APP_ID_ENV = process.env.REPLIT_APP_ID; 

const initFirebase = async () => {
    try {
        const firebaseConfigString = process.env.FIREBASE_CONFIG_JSON;


        if (!firebaseConfigString) {
            console.error("LỖI: Biến môi trường 'FIREBASE_CONFIG_JSON' không tìm thấy. Vui lòng thêm nó vào Replit Secrets.");
            return false;
        }

        let firebaseConfig;
        try {
            firebaseConfig = JSON.parse(firebaseConfigString);
        } catch (parseError) {
            console.error("LỖI: Không thể phân tích 'FIREBASE_CONFIG_JSON'. Đảm bảo nó là một chuỗi JSON hợp lệ.", parseError);
            return false;
        }

        if (Object.keys(firebaseConfig).length === 0) {
            console.error("LỖI: 'FIREBASE_CONFIG_JSON' trống sau khi phân tích. Đảm bảo bạn đã dán cấu hình Firebase chính xác.");
            return false;
        }

        app = initializeApp(firebaseConfig);
        db = getFirestore(app);
        auth = getAuth(app);

        await signInAnonymously(auth);
        console.log('Đăng nhập Firebase ẩn danh thành công.');
        console.log(`Firebase User ID của bot: ${auth.currentUser?.uid}`); 
        console.log(`Firebase Project ID từ config: ${firebaseConfig.projectId}`); 

        client.replitAppId = REPLIT_APP_ID_ENV;

        if (!client.replitAppId) {
            console.warn("CẢNH BÁY: Biến môi trường REPLIT_APP_ID không được thiết lập. Bot sẽ sử dụng giá trị mặc định 'discord-leveling-replit-app'.");
            client.replitAppId = 'discord-leveling-replit-app'; 
        }
        console.log(`Bot sẽ sử dụng Replit App ID: ${client.replitAppId} cho đường dẫn Firestore.`);

        return true;

    } catch (error) {
        console.error("Lỗi khi khởi tạo hoặc xác thực Firebase:", error);
        console.error("Đảm bảo cấu hình Firebase của bạn hợp lệ và các biến bí mật đã được thiết lập đúng trên Replit.");
        return false;
    }
};

// --- Cấu hình Bot Discord ---
const client = new Client({
    intents: [
        GatewayIntentBits.Guilds,
        GatewayIntentBits.GuildMessages,
        GatewayIntentBits.MessageContent,
        GatewayIntentBits.GuildMembers,
        GatewayIntentBits.GuildVoiceStates
    ],
    partials: [Partials.Channel, Partials.Message, Partials.GuildMember, Partials.User, Partials.Reaction]
});

// --- Cấu hình hệ thống cấp độ và vật phẩm ---
const MESSAGE_COOLDOWN_SECONDS = 30; 
const XP_PER_MINUTE_VOICE = 0.001;
const INACTIVITY_RESET_PERIOD_MS = 72 * 60 * 60 * 1000; // 72 giờ
const MIN_MESSAGE_LENGTH = 5; 
const SPAM_MESSAGE_THRESHOLD = 20; 
const GIFT_CODE_LENGTH = 8;

const ADMIN_ROLE_ID = process.env.ADMIN_ROLE_ID;

const SPECIAL_XP_CHANNEL_ID = process.env.SPECIAL_XP_CHANNEL_ID;
const SPECIAL_XP_MULTIPLIER = 2; 
const SPECIAL_CHANNEL_COOLDOWN_SECONDS = 15; 
const SPECIAL_LS_MULTIPLIER = 2; 
const SPECIAL_LS_COOLDOWN_SECONDS = 2 * 60; 


const LS_PER_MESSAGE = 1; 
const LS_GAIN_COOLDOWN_SECONDS = 4 * 60; 

const DAN_X2_EXP_PRICE = 20; 
const DAILY_DAN_X2_EXP_PURCHASE_CAP = 2; 
const DAILY_DAN_X2_EXP_USE_CAP = 2; 
const DAN_X2_EXP_DURATION_MS = 10 * 60 * 1000;

const SHOP_ITEMS = {
    '01': {
        name: 'Đan X2 Exp',
        price: DAN_X2_EXP_PRICE,
        description: 'Nhân đôi Exp nhận được trong 10 phút. Cooldown tin nhắn vẫn là 30s khi dùng.',
        durationMs: DAN_X2_EXP_DURATION_MS,
        xpMultiplier: 2,
        messageCooldownSeconds: 30, 
        dailyPurchaseCap: DAILY_DAN_X2_EXP_PURCHASE_CAP,
        dailyUseCap: DAILY_DAN_X2_EXP_USE_CAP,
        itemCountField: 'danX2ExpItemCount', 
        dailyPurchaseCountField: 'dailyDanX2ExpPurchases', 
        dailyUseCountField: 'dailyDanX2ExpUses' 
    },
    '02': { 
        name: 'Đan Thể Lực',
        price: 5, 
        description: 'Hồi phục 2 Thể Lực.',
        staminaRecovery: 2, 
        itemCountField: 'danTheLucItemCount' 
    },
    '03': {
        name: 'Bùa Chặn Exp',
        price: 10,
        description: 'Khiến mục tiêu trong 10 giờ không nhận được Exp, Linh Thạch và giảm 1 Thể Lực.',
        durationMs: 10 * 60 * 60 * 1000, 
        itemCountField: 'buaChanExpItemCount',
        targetable: true,
        dailyUseCap: 5,
        dailyUseCountField: 'dailyBuaChanExpUses'
    },
    '04': {
        name: 'Bùa Giảm Tỉ Lệ Đột Phá', 
        price: 10,
        description: 'Giảm 5% tỉ lệ đột phá thành công của mục tiêu trong 72 giờ (cộng dồn tối đa 3 bùa).',
        durationMs: 72 * 60 * 60 * 1000, 
        itemCountField: 'buaGiamTiLePhaItemCount', 
        maxStacks: 3,
        reductionPercent: 5,
        targetable: true
    },
    '05': {
        name: 'Bùa Phá Giải',
        price: 10,
        description: 'Hóa giải 1 hiệu ứng bất lợi từ Bùa Chặn Exp hoặc Bùa Giảm Tỉ Lệ Đột Phá.',
        itemCountField: 'buaPhaGiaiItemCount',
        targetable: false
    },
    '06': {
        name: 'Hấp Tinh Đại Pháp',
        price: 100,
        description: 'Sách công pháp, học để sở hữu kỹ năng làm giảm 2 điểm thể lực của đối phương. Dùng lệnh !dung06 để học.',
        itemCountField: 'hapTinhDaiPhapItemCount',
        skillName: 'hapTinhDaiPhap'
    }
};

// CƠ CHẾ MỚI: xpNeeded là lượng Exp cần cày ở cảnh giới TRƯỚC ĐÓ để đột phá.
const LEVELS = [
    { level: 0, name: 'Phàm Nhân', xpNeeded: 0, roleId: '1380534931712901211', messagesNeededForXp: 1, breakthroughChance: 100, maxStamina: 0 },
    { level: 1, name: 'Luyện Khí', xpNeeded: 100, roleId: '1380535433166852146', messagesNeededForXp: 2, breakthroughChance: 100, maxStamina: 4 },
    { level: 5, name: 'Trúc Cơ', xpNeeded: 500, roleId: '1380535498010919084', messagesNeededForXp: 3, breakthroughChance: 80, maxStamina: 6 },
    { level: 10, name: 'Kết Đan', xpNeeded: 1500, roleId: '1380535654894534777', messagesNeededForXp: 4, breakthroughChance: 85, maxStamina: 8 },
    { level: 20, name: 'Nguyên Anh', xpNeeded: 3000, roleId: '1380535772939161622', messagesNeededForXp: 5, breakthroughChance: 80, maxStamina: 10 },
    { level: 30, name: 'Hóa Thần', xpNeeded: 4500, roleId: '1380535823941767260', messagesNeededForXp: 6, breakthroughChance: 65, maxStamina: 12 },
    { level: 40, name: 'Đại Thừa', xpNeeded: 7000, roleId: '1380537500086571111', messagesNeededForXp: 7, breakthroughChance: 70, maxStamina: 14 },
    { level: 50, name: 'Độ Kiếp', xpNeeded: 8500, roleId: '1380537622710980679', messagesNeededForXp: 8, breakthroughChance: 65, maxStamina: 16 },
    { level: 60, name: 'Đăng Tiên', xpNeeded: 13000, roleId: '1380537656966119444', messagesNeededForXp: 9, breakthroughChance: 60, maxStamina: 18 },
    { level: 70, name: 'Chân Tiên', xpNeeded: 18500, roleId: '1380537749169504396', messagesNeededForXp: 10, breakthroughChance: 65, maxStamina: 20 },
    { level: 80, name: 'Đại La Kim Tiên', xpNeeded: 27000, roleId: '1380538139684114472', messagesNeededForXp: 11, breakthroughChance: 60, maxStamina: 22 },
    { level: 90, name: 'Bán Thánh', xpNeeded: 40500, roleId: '1380538253957922958', messagesNeededForXp: 12, breakthroughChance: 55, maxStamina: 24 },
    { level: 100, name: 'Thánh Nhân', xpNeeded: 66666, roleId: '1380538433256165436', messagesNeededForXp: 13, breakthroughChance: 45, maxStamina: 66 },
];

const SONGTU_OFFER_TIMEOUT_MS = 1 * 60 * 1000;
const KNST_WINDOW_MS = 60 * 1000;
const KNST_BOOST_DURATION_MS = 15 * 60 * 1000;
const KNST_PENALTY_PERCENT = 0.05; 
const HUYDAOLU_COST = 5; 
const STAMINA_DEPLETED_MESSAGE_COOLDOWN_MS = 5 * 60 * 1000; 

const PUNISH_ROLE_ID = '1315688660066238484'; 

const userLastMessageTime = new Map(); 
const userVoiceJoinTimes = new Map();
const channelLastSender = new Map(); 
const knstRequests = new Map(); 
const dslPagesTracker = new Map(); 
const staminaDepletedMessageSent = new Map();
const bxhDataTracker = new Map(); 
const bxhPagesTracker = new Map(); 

// ====================================================================
// --- CÁC HÀM TIỆN ÍCH VÀ XỬ LÝ DỮ LIỆU ---
// ====================================================================

function getLevelConfig(level) {
    return LEVELS.find(l => l.level === level);
}

function getNextLevelConfig(currentLevel) {
    const currentIndex = LEVELS.findIndex(l => l.level === currentLevel);
    if (currentIndex !== -1 && currentIndex < LEVELS.length - 1) {
        return LEVELS[currentIndex + 1];
    }
    return null; 
}

function getDailyLinhThachCap(level) {
    const realmIndex = LEVELS.findIndex(l => l.level === level);

    if (realmIndex <= 1) {
        return 50;
    }

    const trucCoIndex = LEVELS.findIndex(l => l.name === 'Trúc Cơ'); 
    if (realmIndex >= trucCoIndex && trucCoIndex !== -1) {
        return 60 + (realmIndex - trucCoIndex) * 10;
    }

    return 50;
}


async function getUserData(discordId) {
    if (!db || !client.replitAppId) {
        console.error("Firestore chưa được khởi tạo đầy đủ hoặc Replit App ID không khả dụng.");
        return null; // Return null to indicate failure
    }
    const userDocRef = doc(db, `artifacts/${client.replitAppId}/public/data/discordBotLevels`, discordId);
    try {
        const docSnap = await getDoc(userDocRef, { source: 'server' }); 
        const now = Date.now(); 

        if (docSnap.exists()) {
            const data = docSnap.data();
            const level = typeof data.level === 'number' ? data.level : 0;
            const levelConfig = getLevelConfig(level);
            const levelName = levelConfig ? levelConfig.name : 'Phàm Nhân';
            const maxStamina = levelConfig ? levelConfig.maxStamina : 0;

            let userData = {
                level: level,
                xp: typeof data.xp === 'number' ? data.xp : 0,
                cumulativeXp: typeof data.cumulativeXp === 'number' ? data.cumulativeXp : 0,
                name: levelName,
                maxStamina: maxStamina,
                messagesSinceLastXPGain: typeof data.messagesSinceLastXPGain === 'number' ? data.messagesSinceLastXPGain : 0,
                hasStartedCultivation: data.hasStartedCultivation === true,
                lastActivityTime: typeof data.lastActivityTime === 'number' ? data.lastActivityTime : 0,
                consecutiveMessages: typeof data.consecutiveMessages === 'number' ? data.consecutiveMessages : 0,
                redeemedCodes: Array.isArray(data.redeemedCodes) ? data.redeemedCodes : [],
                danX2ExpItemCount: typeof data.danX2ExpItemCount === 'number' ? data.danX2ExpItemCount : 0,
                activeBoost: data.activeBoost && data.activeBoost.endTime > now ? data.activeBoost : { type: null, endTime: null, messageCooldownSeconds: null, xpMultiplier: null },
                linhThach: typeof data.linhThach === 'number' ? data.linhThach : 0, 
                lastLinhThachGainTime: typeof data.lastLinhThachGainTime === 'number' ? data.lastLinhThachGainTime : 0, 
                dailyLinhThachGained: typeof data.dailyLinhThachGained === 'number' ? data.dailyLinhThachGained : 0, 
                dailyDanX2ExpPurchases: typeof data.dailyDanX2ExpPurchases === 'number' ? data.dailyDanX2ExpPurchases : 0, 
                dailyDanX2ExpUses: typeof data.dailyDanX2ExpUses === 'number' ? data.dailyDanX2ExpUses : 0,
                dailyBuaChanExpUses: typeof data.dailyBuaChanExpUses === 'number' ? data.dailyBuaChanExpUses : 0,
                currentStamina: typeof data.currentStamina === 'number' ? Math.min(data.currentStamina, maxStamina) : maxStamina,
                xpSinceLastStaminaDeduct: typeof data.xpSinceLastStaminaDeduct === 'number' ? data.xpSinceLastStaminaDeduct : 0, 
                danTheLucItemCount: typeof data.danTheLucItemCount === 'number' ? data.danTheLucItemCount : 0,
                songTuPartnerId: typeof data.songTuPartnerId === 'string' ? data.songTuPartnerId : null,
                songTuSkillLastUsed: typeof data.songTuSkillLastUsed === 'number' ? data.songTuSkillLastUsed : 0,
                songTuSkillActiveEndTime: typeof data.songTuSkillActiveEndTime === 'number' ? data.songTuSkillActiveEndTime : 0,
                songTuSkillDailyUseCount: typeof data.songTuSkillDailyUseCount === 'number' ? data.songTuSkillDailyUseCount : 0,
                isWaitingForSongTuAccept: typeof data.isWaitingForSongTuAccept === 'boolean' ? data.isWaitingForSongTuAccept : false,
                songTuInitiatorId: typeof data.songTuInitiatorId === 'string' ? data.songTuInitiatorId : null,
                songTuOfferTimestamp: typeof data.songTuOfferTimestamp === 'number' ? data.songTuOfferTimestamp : 0,
                songTuOfferMessageId: typeof data.songTuOfferMessageId === 'string' ? data.songTuOfferMessageId : null,
                buaChanExpItemCount: typeof data.buaChanExpItemCount === 'number' ? data.buaChanExpItemCount : 0,
                buaGiamTiLePhaItemCount: typeof data.buaGiamTiLePhaItemCount === 'number' ? data.buaGiamTiLePhaItemCount : 0,
                buaPhaGiaiItemCount: typeof data.buaPhaGiaiItemCount === 'number' ? data.buaPhaGiaiItemCount : 0,
                activeExpBlockTalismans: Array.isArray(data.activeExpBlockTalismans) ? data.activeExpBlockTalismans.filter(bua => bua.endTime > now) : [],
                activeBreakthroughReduceTalismans: Array.isArray(data.activeBreakthroughReduceTalismans) ? data.activeBreakthroughReduceTalismans.filter(bua => bua.endTime > now) : [],
                punishedUntil: typeof data.punishedUntil === 'number' && data.punishedUntil > now ? data.punishedUntil : null,
                punishedChannelId: (typeof data.punishedUntil === 'number' && data.punishedUntil > now) ? (typeof data.punishedChannelId === 'string' ? data.punishedChannelId : null) : null,
                punishmentDurationMinutes: (typeof data.punishedUntil === 'number' && data.punishedUntil > now) ? (typeof data.punishmentDurationMinutes === 'number' ? data.punishmentDurationMinutes : null) : null,
                spamPunishedUntil: typeof data.spamPunishedUntil === 'number' && data.spamPunishedUntil > now ? data.spamPunishedUntil : null,
                hapTinhDaiPhapItemCount: typeof data.hapTinhDaiPhapItemCount === 'number' ? data.hapTinhDaiPhapItemCount : 0,
                learnedSkills: Array.isArray(data.learnedSkills) ? data.learnedSkills : [],
                skillCooldowns: typeof data.skillCooldowns === 'object' && data.skillCooldowns !== null ? data.skillCooldowns : {},
                inactivityNotified: typeof data.inactivityNotified === 'boolean' ? data.inactivityNotified : false,

                // --- BẮT ĐẦU MÃ NHẬP VAI ---
                rolePlaying: data.rolePlaying || {
                    isActive: false,
                    characterName: null,
                    storyHistory: [],
                    lastChoices: [],
                    currentMessageId: null,
                    channelId: null
                }
                // --- KẾT THÚC MÃ NHẬP VAI ---
            };
            return userData;
        }
        // Trả về cấu trúc cho người dùng hoàn toàn mới
        return { 
            level: 0,
            xp: 0, 
            cumulativeXp: 0, 
            name: 'Phàm Nhân', 
            maxStamina: 0,
            messagesSinceLastXPGain: 0, 
            hasStartedCultivation: false, 
            lastActivityTime: 0, 
            consecutiveMessages: 0, 
            redeemedCodes: [], 
            danX2ExpItemCount: 0, 
            activeBoost: { type: null, endTime: null, messageCooldownSeconds: null, xpMultiplier: null }, 
            linhThach: 0, 
            lastLinhThachGainTime: 0, 
            dailyLinhThachGained: 0, 
            dailyDanX2ExpPurchases: 0, 
            dailyDanX2ExpUses: 0, 
            dailyBuaChanExpUses: 0,
            currentStamina: 0, 
            xpSinceLastStaminaDeduct: 0, 
            danTheLucItemCount: 0, 
            songTuPartnerId: null, 
            songTuSkillLastUsed: 0, 
            songTuSkillActiveEndTime: 0,
            songTuSkillDailyUseCount: 0, 
            isWaitingForSongTuAccept: false, 
            songTuInitiatorId: null,
            songTuOfferTimestamp: 0, 
            songTuOfferMessageId: null, 
            buaChanExpItemCount: 0,
            buaGiamTiLePhaItemCount: 0, 
            buaPhaGiaiItemCount: 0, 
            activeExpBlockTalismans: [],
            activeBreakthroughReduceTalismans: [], 
            punishedUntil: null, 
            punishedChannelId: null, 
            punishmentDurationMinutes: null, 
            spamPunishedUntil: null, 
            hapTinhDaiPhapItemCount: 0,
            learnedSkills: [], 
            skillCooldowns: {}, 
            inactivityNotified: false,
            // --- BẮT ĐẦU MÃ NHẬP VAI ---
            rolePlaying: {
                isActive: false,
                characterName: null,
                storyHistory: [],
                lastChoices: [],
                currentMessageId: null,
                channelId: null
            }
            // --- KẾT THÚC MÃ NHẬP VAI ---
        };
    } catch (error) {
        console.error(`Lỗi khi lấy dữ liệu người dùng ${discordId} từ Firestore:`, error);
        return null;
    }
}

async function getAllUserData(fullData = false) {
    if (!db || !client.replitAppId) {
        console.error("Firestore chưa được khởi tạo đầy đủ hoặc Replit App ID không khả dụng. Không thể lấy tất cả dữ liệu người dùng.");
        return [];
    }
    const usersCollectionRef = collection(db, `artifacts/${client.replitAppId}/public/data/discordBotLevels`);
    try {
        const querySnapshot = await getDocs(usersCollectionRef, { source: 'server' }); 
        const allUsersData = [];

        querySnapshot.forEach(docSnap => {
            const data = docSnap.data();
            if (data.hasStartedCultivation) {
                if (fullData) {
                    allUsersData.push({ discordId: docSnap.id, ...data });
                } else {
                     const levelConfig = getLevelConfig(data.level || 0);
                     allUsersData.push({
                        discordId: docSnap.id,
                        cumulativeXp: typeof data.cumulativeXp === 'number' ? data.cumulativeXp : 0,
                        level: data.level || 0,
                        name: levelConfig ? levelConfig.name : 'Phàm Nhân',
                        linhThach: typeof data.linhThach === 'number' ? data.linhThach : 0,
                        songTuPartnerId: typeof data.songTuPartnerId === 'string' ? data.songTuPartnerId : null,
                    });
                }
            }
        });
        return allUsersData;
    } catch (error) {
        console.error(`Lỗi khi lấy tất cả dữ liệu người dùng từ Firestore:`, error);
        return [];
    }
}

async function updateUserData(discordId, data) {
    if (!db || !client.replitAppId) {
        console.error("Firestore chưa được khởi tạo đầy đủ hoặc Replit App ID không khả dụng. Không thể cập nhật dữ liệu người dùng.");
        return;
    }
    const userDocRef = doc(db, `artifacts/${client.replitAppId}/public/data/discordBotLevels`, discordId);
    try {
        // Chỉ loại bỏ các thuộc tính được tính toán động, giữ lại level và xp
        const { name, maxStamina, ...dataToSave } = data;
        await setDoc(userDocRef, dataToSave, { merge: true });
    } catch (error) {
        console.error(`[Firestore Write ERROR] Lỗi khi cập nhật dữ liệu người dùng ${discordId} trong Firestore:`, error);
    }
}

async function updateUserRole(member, newLevel) {
    if (!member) {
        console.error("Hàm updateUserRole được gọi nhưng thiếu đối tượng 'member'.");
        return;
    }
    const guild = member.guild;

    const newLevelConfig = getLevelConfig(newLevel);
    if (!newLevelConfig || !newLevelConfig.roleId) {
        console.log(`Không tìm thấy cấu hình vai trò cho cấp ${newLevel}.`);
        return;
    }

    const newRole = guild.roles.cache.get(newLevelConfig.roleId);
    if (!newRole) {
        console.error(`LỖI CẤU HÌNH: Vai trò với ID ${newLevelConfig.roleId} cho cảnh giới "${newLevelConfig.name}" không tìm thấy trên máy chủ. Vui lòng kiểm tra lại ID vai trò.`);
        return;
    }

    if (guild.members.me.roles.highest.position <= newRole.position) {
         console.error(`LỖI QUYỀN HẠN: Vai trò của bot (${guild.members.me.roles.highest.name}) không được đặt cao hơn vai trò cảnh giới (${newRole.name}) trong danh sách vai trò của máy chủ. Bot không thể gán vai trò này.`);
         return;
    }

    const allConfiguredRoleIds = LEVELS.filter(l => l.roleId).map(l => l.roleId);

    try {
        const rolesToRemove = member.roles.cache.filter(role => allConfiguredRoleIds.includes(role.id) && role.id !== newLevelConfig.roleId);

        if (rolesToRemove.size > 0) {
            await member.roles.remove(rolesToRemove, 'Hệ thống tu tiên: Cập nhật vai trò cảnh giới.');
        }

        if (!member.roles.cache.has(newLevelConfig.roleId)) {
            await member.roles.add(newRole, 'Hệ thống tu tiên: Cấp vai trò cảnh giới mới.');
        }
    } catch (error) {
        console.error(`Lỗi khi cập nhật vai trò cho ${member.user.tag}:`, error);
        if (error.code === 50013) { 
            console.error(`LỖI: Bot thiếu quyền 'Manage Roles'. Đảm bảo bot có quyền và vai trò của nó cao hơn vai trò "${newRole.name}".`);
        }
    }
}


async function getGiftCode(codeString) {
    if (!db || !client.replitAppId) return null;
    const codeDocRef = doc(db, `artifacts/${client.replitAppId}/public/data/discordBotGiftCodes`, codeString);
    try {
        const docSnap = await getDoc(codeDocRef, { source: 'server' }); 
        if (docSnap.exists()) {
            return docSnap.data();
        }
        return null; 
    } catch (error) {
        console.error(`Lỗi khi lấy dữ liệu gift code ${codeString} từ Firestore:`, error);
        return null;
    }
}

// --- BẮT ĐẦU CÁC HÀM HỖ TRỢ NHẬP VAI ---

// Hàm gọi AI Gemini
async function callGeminiAI(history) {
    try {
        const chat = model.startChat({
            history: history,
            generationConfig: { maxOutputTokens: 800 },
        });
        const prompt = "Hãy kể tiếp câu chuyện phiêu lưu một cách hấp dẫn. Cuối cùng, hãy đưa ra đúng 3 lựa chọn hành động rõ ràng và khác biệt cho người chơi. Trả về dưới dạng một chuỗi JSON duy nhất và không có gì khác, với cấu trúc: {\"story\": \"nội dung câu chuyện...\", \"choices\": [\"lựa chọn 1\", \"lựa chọn 2\", \"lựa chọn 3\"]}. Không bao giờ thêm ký tự ```json hoặc ``` ở đầu và cuối.";
        const result = await chat.sendMessage(prompt);
        const responseText = result.response.text();
        const jsonMatch = responseText.match(/\{[\s\S]*\}/);
        if (jsonMatch) {
            return JSON.parse(jsonMatch[0]);
        }
        return { story: responseText, choices: ["Thử lại", "Chờ một lát", "Bỏ qua"] };
    } catch (error) {
        console.error("Lỗi khi gọi Gemini AI:", error);
        return { story: "Một thế lực bí ẩn đã tạm thời chặn đứng dòng chảy của số phận. (Lỗi AI)", choices: ["Thử lại sau", "Kết thúc", "Hủy"] };
    }
}

// Hàm gửi tin nhắn cốt truyện
async function sendStoryMessage(interaction, userData, aiResponse) {
    const { characterName } = userData.rolePlaying;
    const { story, choices } = aiResponse;

    // 1. Tạo nội dung tin nhắn với danh sách lựa chọn
    let storyContent = `**Cốt truyện của ${characterName}**\n\n${story}`;
    let choiceText = "\n\n**Các lựa chọn của bạn:**\n";
    choices.forEach((choice, index) => {
        choiceText += `${index + 1}. ${choice}\n`;
    });
    storyContent += choiceText;

    // 2. Tạo các nút bấm
    const row = new ActionRowBuilder().addComponents(
        new ButtonBuilder().setCustomId('rpg_choice_0').setLabel('1').setStyle(ButtonStyle.Secondary),
        new ButtonBuilder().setCustomId('rpg_choice_1').setLabel('2').setStyle(ButtonStyle.Secondary),
        new ButtonBuilder().setCustomId('rpg_choice_2').setLabel('3').setStyle(ButtonStyle.Secondary),
        new ButtonBuilder().setCustomId('rpg_custom_action').setLabel('Hành động khác (-1 LT)').setStyle(ButtonStyle.Primary)
    );

    // 3. Gửi hoặc sửa tin nhắn
    const messagePayload = { content: storyContent, components: [row] };
    const storyMessage = interaction.replied || interaction.deferred
        ? await interaction.editReply(messagePayload)
        : await interaction.channel.send(messagePayload);

    // 4. Cập nhật lại dữ liệu người dùng
    userData.rolePlaying.currentMessageId = storyMessage.id;
    userData.rolePlaying.lastChoices = choices;
    userData.rolePlaying.channelId = interaction.channelId;
    await updateUserData(interaction.user.id, userData);
}
// --- KẾT THÚC CÁC HÀM HỖ TRỢ NHẬP VAI ---

// ====================================================================
// --- NỘI DUNG VÀ CẤU TRÚC LỆNH ---
// ====================================================================

const DSL_PAGES = [
    {
        title: '__**Danh sách các lệnh của Chư Thiên Vạn Giới (Trang 1/5)**__',
        content: `\`\`\`ini
[Lệnh] - Mô tả và Cách dùng
-------------------------------------------
[!batdaututien] - Bắt đầu con đường tu tiên của bạn.
[!kn] - Kiểm tra kinh nghiệm (Exp) và cảnh giới hiện tại, số Linh Thạch.
[!bxh] - Xem bảng xếp hạng tu luyện của máy chủ.
[!tuvi] - Xem danh sách cảnh giới & kinh nghiệm yêu cầu.
[!dslenh] - Hiển thị danh sách các lệnh này.
[!code [Mã Code]] - Nhập mã code để nhận phần thưởng.
[!ch] - Mở Cửa hàng Chư Thiên Vạn Giới.
[!mua<ID> <số lượng>] - Mua vật phẩm từ cửa hàng.
[!dung<ID> <sl>] - Sử dụng vật phẩm đã mua.
[!dung<ID> <sl> <@user>] - Dùng vật phẩm lên người khác.
[!cp<ID công pháp> <@người_dùng>] - Dùng công pháp đã học.
[!songtu <@người_dùng>] - Gửi lời mời song tu.
[!knst <@đạo_lữ> <nội_dung>] - Kích hoạt kỹ năng song tu.
[!huydaolu <@đạo_lữ>] - Hủy bỏ đạo lữ song tu.
[!tg] - Xem thông tin cooldown Exp/Linh Thạch và các hiệu ứng hiện tại.
\`\`\``
    },
    {
        title: '__**Quy tắc nhận Exp & Đột phá (Trang 2/5)**__',
        content: `*Lưu ý: Các tin nhắn phải từ **${MIN_MESSAGE_LENGTH} ký tự** trở lên mới được tính Exp (nếu đã bắt đầu tu luyện).
*Kênh thông thường: Mỗi người chơi chỉ có thể nhận Exp từ tin nhắn sau mỗi **${MESSAGE_COOLDOWN_SECONDS} giây**.
*Spam: Nếu nhắn tin liên tục quá **${SPAM_MESSAGE_THRESHOLD} lần** mà không có tin nhắn của người khác chen vào, Exp cảnh giới hiện tại của bạn sẽ bị trừ 50% và bạn sẽ bị cấm nhận Exp/Linh Thạch trong 30 phút.
*Kênh thông thường: Từ cảnh giới **Trúc Cơ** trở lên, đột phá cảnh giới sẽ có **tỉ lệ thất bại**. Nếu thất bại sẽ bị trừ **10% kinh nghiệm** của cảnh giới hiện tại đang có.

*Nếu không hoạt động trong hơn **${INACTIVITY_RESET_PERIOD_MS / (1000 * 60 * 60)} giờ**, Exp cảnh giới hiện tại của bạn sẽ giảm **một nửa**.
${SPECIAL_XP_CHANNEL_ID ? `
__**Động Thiên Phúc Địa (<#${SPECIAL_XP_CHANNEL_ID}>):**__
* Chỉ mở **1 ngày vào cuối tuần (Thứ 7 hoặc Chủ nhật)**, mỗi lần mở **1 tiếng**.
* Cooldown tin nhắn là **${SPECIAL_CHANNEL_COOLDOWN_SECONDS} giây**. Exp và Linh thạch nhận được sẽ được **nhân đôi**. Cooldown Linh Thạch giảm còn **2 phút**.
* **Trong kênh này, không bị giới hạn Linh Thạch hàng ngày và không bị phạt vì spam hay không hoạt động!**` : ''}`
    },
    {
        title: '__**Hệ Thống Linh Thạch & Thể Lực (Trang 3/5)**__',
        content: `__**Kiếm Linh Thạch:**__
* Nhắn tin (từ ${MIN_MESSAGE_LENGTH} ký tự): **1 Linh Thạch**/tin nhắn (sau **${Math.floor(LS_GAIN_COOLDOWN_SECONDS / 60)} phút** cooldown).
* Giới hạn Linh Thạch/ngày: **50** (Phàm Nhân, Luyện Khí), **60** (Trúc Cơ), và **+10** cho mỗi cảnh giới sau.
* **Đan X2 Exp**: Giới hạn mua **${DAILY_DAN_X2_EXP_PURCHASE_CAP} cái**/ngày, giới hạn dùng **${DAILY_DAN_X2_EXP_USE_CAP} cái**/ngày.

__**Hệ Thống Thể Lực (Từ cảnh giới Luyện Khí trở lên):**__
* Cứ mỗi **10 Exp** nhận được từ tin nhắn trong kênh thông thường, Thể Lực sẽ giảm **1 điểm**.
* **Trong Động Thiên Phúc Địa, Thể Lực sẽ không bị hao tổn khi bạn nhắn tin.**
* Nếu Thể Lực còn **một nửa hoặc ít hơn**, thời gian cooldown để nhận 1 Exp từ tin nhắn sẽ **tăng lên 3 phút**, và thời gian cooldown Linh Thạch sẽ **tăng lên 5 phút**.
* Nếu Thể Lực về **0**, bạn sẽ **không nhận được Exp và Linh Thạch** từ tin nhắn.
* **Đan Thể Lực (ID 02)**: Dùng để hồi phục Thể Lực. Không giới hạn số lần mua/dùng.`
    },
    {
        title: '__**Công pháp, Bùa Chú & Song Tu (Trang 4/5)**__',
        content: `__**Công Pháp:**__
* **Hấp Tinh Đại Pháp (ID 06)**: Dùng \`!cp06 <@user>\` để sử dụng. Công pháp sẽ làm giảm 2 điểm Thể Lực của đối phương. Nếu không đủ, sẽ trừ tiếp vào Linh Thạch và cuối cùng là Exp.(Thời gian hồi 30 phút)
* **(khi dùng -3 linh thạch nếu mục tiêu cùng cảnh giới và thấp hơn, -6, -10 linh thạch nếu mục tiêu hơn 1, 2 cảnh giới.)
* **Ngoài ra, có tỉ lệ hút trộm được Linh Thạch của đối thủ (20% hút được 4 linh thạch nếu mục tiêu cùng cảnh giới hoặc thấp hơn, 15%, 10% hút được 8, 12 linh thạch nếu mục tiêu cao hơn 1, 2 cảnh giới).
* **Không có tác dụng đối với phàm nhân và người cao hơn trên 3 cảnh giới.

__**Bùa Chú:**__
* **Bùa Chặn Exp (ID 03)**: Dùng \`!dung03 <sl> <@user>\`. Khiến mục tiêu trong **10 giờ** không nhận Exp/Linh Thạch, giảm **1 Thể Lực**. Có giới hạn dùng 5 lần/ngày và tốn thêm Linh Thạch nếu mục tiêu có cảnh giới cao hơn.
* **(Nếu mục tiêu có cảnh giới bằng và thấp hơn thì không tốn linh thạch. Nếu cao hơn 1, 2, 3 cảnh giới, bạn sẽ phải trả thêm 5, 10, 20 Linh thạch. Nếu cao hơn 4 cảnh giới, bùa sẽ không có tác dụng.)
* **Bùa Giảm Tỉ Lệ (ID 04)**: Dùng \`!dung04 <sl> <@user>\`. Giảm **5%** tỉ lệ đột phá trong **72 giờ** (cộng dồn tối đa 3 bùa). Dùng bùa này sẽ ẩn danh.
* **Bùa Phá Giải (ID 05)**: Dùng \`!dung05 <sl>\`. Hóa giải 1 hiệu ứng bất lợi từ Bùa Chặn Exp hoặc Bùa Giảm Tỉ Lệ Đột Phá.`
    },
    {
        title: '__**Kỹ năng Song Tu (Trang 5/5)**__',
        content: `__**Kỹ năng Song Tu (Chỉ dùng khi đã có đạo lữ):**__
* Lệnh \`!knst\`: Cả hai người phải cùng dùng lệnh này trong vòng **${KNST_WINDOW_MS / 1000} giây** và với **cùng nội dung tin nhắn**.
* Thành công: Exp nhận được sẽ **nhân đôi** trong **${KNST_BOOST_DURATION_MS / (60 * 1000)} phút**.
* Giới hạn: Chỉ dùng được **1 lần mỗi ngày**.
* Thất bại (dùng quá lần/ngày): Mỗi người bị **trừ ${KNST_PENALTY_PERCENT * 100}% tổng Exp tích lũy**.

__**Hủy Đạo Lữ Song Tu:**__
* Lệnh \`!huydaolu <@đạo_lữ>\`: Đơn phương hủy bỏ mối quan hệ song tu.
* Chi phí: **${HUYDAOLU_COST} Linh Thạch**.
* Khi hủy: Cả hai người sẽ không còn là đạo lữ nữa. Trạng thái song tu trong lệnh \`!kn\` sẽ hiển thị "Độc thân".`
    }
];


// ====================================================================
// --- KHỞI CHẠY BOT VÀ LẮNG NGHE SỰ KIỆN ---
// ====================================================================

client.once('ready', async () => {
    console.log(`Bot đã sẵn sàng! Đăng nhập với tư cách ${client.user.tag}`);
    const firebaseInitialized = await initFirebase();
    if (!firebaseInitialized) {
        console.error("Firebase không thể khởi tạo. Bot có thể không hoạt động như mong đợi.");
    } else {
        if (!ADMIN_ROLE_ID) {
            console.warn("CẢNH BÁO: ADMIN_ROLE_ID chưa được thiết lập trong Replit Secrets. Lệnh !taocode sẽ không hoạt động.");
        }
        // Khởi động các tác vụ định kỳ
        runDailyTasks();
        runInactivityCheck();
    }
});

client.on('interactionCreate', async interaction => {
    if (!interaction.isButton() && !interaction.isModalSubmit()) return; 

    const customIdParts = interaction.customId.split('_');
    const action = customIdParts[0];

    // Handler for !dslenh pagination
    if (action === 'dsl') {
        let currentPageIndex = dslPagesTracker.get(interaction.message.id);
        if (currentPageIndex === undefined) {
            await interaction.reply({ content: 'Tin nhắn hướng dẫn này đã cũ hoặc không còn hoạt động. Vui lòng gõ `!dslenh` để tạo tin nhắn mới.', flags: [64] });
            return;
        }

        const maxPageIndex = DSL_PAGES.length - 1;
        const direction = customIdParts[1];

        if (direction === 'prev') {
            currentPageIndex = Math.max(0, currentPageIndex - 1);
        } else if (direction === 'next') {
            currentPageIndex = Math.min(maxPageIndex, currentPageIndex + 1);
        }
        dslPagesTracker.set(interaction.message.id, currentPageIndex);

        const currentPage = DSL_PAGES[currentPageIndex];
        currentPage.title = currentPage.title.replace(/\(Trang \d+\/\d+\)/, `(Trang ${currentPageIndex + 1}/${DSL_PAGES.length})`);

        const newRow = new ActionRowBuilder()
            .addComponents(
                new ButtonBuilder()
                    .setCustomId('dsl_prev')
                    .setLabel('Trang trước')
                    .setStyle(ButtonStyle.Primary)
                    .setDisabled(currentPageIndex === 0),
                new ButtonBuilder()
                    .setCustomId('dsl_next')
                    .setLabel('Trang kế tiếp')
                    .setStyle(ButtonStyle.Primary)
                    .setDisabled(currentPageIndex === maxPageIndex),
            );

        await interaction.update({
            content: `${currentPage.title}\n${currentPage.content}`,
            components: [newRow]
    // --- BẮT ĐẦU LOGIC NHẬP VAI HOÀN CHỈNH ---

    // Xử lý khi người dùng gửi form tạo nhân vật
    if (interaction.isModalSubmit() && interaction.customId === 'nhapvai_setup_modal') {
        await interaction.deferReply({ ephemeral: false });

        const userId = interaction.user.id;
        let userData = await getUserData(userId);

        // Thiết lập dữ liệu cho game mới
        userData.rolePlaying = {
            isActive: true,
            characterName: interaction.fields.getTextInputValue('char_name'),
            storyHistory: [{ role: "user", parts: [{ text: `Hãy bắt đầu một câu chuyện nhập vai phiêu lưu kỳ ảo cho nhân vật của tôi. Tên: ${interaction.fields.getTextInputValue('char_name')}, Cốt truyện: ${interaction.fields.getTextInputValue('char_backstory')}.` }] }],
            lastChoices: [],
            currentMessageId: null,
            channelId: interaction.channelId
        };

        const aiResponse = await callGeminiAI(userData.rolePlaying.storyHistory);
        userData.rolePlaying.storyHistory.push({ role: "model", parts: [{ text: aiResponse.story }] });

        await sendStoryMessage(interaction, userData, aiResponse);
    }

    // Xử lý khi người dùng nhấn nút lựa chọn CÓ SẴN (1, 2, 3)
    if (interaction.isButton() && interaction.customId.startsWith('rpg_choice_')) {
        const userId = interaction.user.id;
        let userData = await getUserData(userId);

        if (!userData.rolePlaying?.isActive || interaction.message.id !== userData.rolePlaying.currentMessageId) {
            return interaction.reply({ content: "Đây không phải là cuộc phiêu lưu hiện tại của bạn hoặc nó đã cũ.", flags: [64] });
        }

        await interaction.deferUpdate(); // Báo cho Discord biết bot đã nhận lệnh

        try { // Vô hiệu hóa các nút trên tin nhắn cũ
            await interaction.message.edit({ components: [] });
        } catch(e) {}

        const choiceIndex = parseInt(interaction.customId.split('_')[2], 10);
        const choiceText = userData.rolePlaying.lastChoices[choiceIndex];
        const finalAction = `Tôi chọn: "${choiceText}"`;

        userData.rolePlaying.storyHistory.push({ role: "user", parts: [{ text: finalAction }] });
        const aiResponse = await callGeminiAI(userData.rolePlaying.storyHistory);
        userData.rolePlaying.storyHistory.push({ role: "model", parts: [{ text: aiResponse.story }] });

        await sendStoryMessage(interaction, userData, aiResponse);
    }

    // Xử lý khi người dùng nhấn nút "Hành động khác"
    if (interaction.isButton() && interaction.customId === 'rpg_custom_action') {
        const modal = new ModalBuilder().setCustomId('rpg_custom_action_submit').setTitle('Hành Động Tùy Chỉnh');
        const actionInput = new TextInputBuilder().setCustomId('custom_action_input').setLabel("Bạn muốn làm gì? (Sẽ tốn 1 Linh Thạch)").setStyle(TextInputStyle.Paragraph).setPlaceholder("Mô tả hành động của bạn...").setRequired(true);
        modal.addComponents(new ActionRowBuilder().addComponents(actionInput));
        await interaction.showModal(modal);
    }

    // Xử lý khi người dùng gửi form hành động tùy chỉnh
    if (interaction.isModalSubmit() && interaction.customId === 'rpg_custom_action_submit') {
        const userId = interaction.user.id;
        let userData = await getUserData(userId);

        if (userData.linhThach < 1) {
            return interaction.reply({ content: 'Bạn không đủ 1 Linh Thạch để thực hiện hành động này!', flags: [64] });
        }

        await interaction.deferUpdate();

        try { // Vô hiệu hóa các nút trên tin nhắn cũ
            await interaction.message.edit({ components: [] });
        } catch (e) {}

        userData.linhThach -= 1;
        const customActionText = interaction.fields.getTextInputValue('custom_action_input');
        const finalAction = `Hành động của tôi là: "${customActionText}"`;

        userData.rolePlaying.storyHistory.push({ role: "user", parts: [{ text: finalAction }] });
        const aiResponse = await callGeminiAI(userData.rolePlaying.storyHistory);
        userData.rolePlaying.storyHistory.push({ role: "model", parts: [{ text: aiResponse.story }] });

        await sendStoryMessage(interaction, userData, aiResponse);
    }
    // --- KẾT THÚC LOGIC NHẬP VAI HOÀN CHỈNH ---		
        });
        return; 
    }

    // Handler for !bxh pagination
    if (action === 'bxh') {
        const messageId = interaction.message.id;
        const allUsers = bxhDataTracker.get(messageId);
        const pageData = bxhPagesTracker.get(messageId);

        if (!allUsers || !pageData) {
            return interaction.update({ content: 'Bảng xếp hạng này đã cũ. Vui lòng gõ `!bxh` để xem lại.', components: [] });
        }

        let { currentPage, totalPages, usersPerPage } = pageData;
        const direction = customIdParts[1];

        if (direction === 'prev') {
            currentPage = Math.max(1, currentPage - 1);
        } else if (direction === 'next') {
            currentPage = Math.min(totalPages, currentPage + 1);
        }

        const start = (currentPage - 1) * usersPerPage;
        const end = start + usersPerPage;
        const pageUsers = allUsers.slice(start, end);

        let leaderboardMessage = `__**Bảng Xếp Hạng Tu Luyện (Trang ${currentPage}/${totalPages})**__\n\n`;
        leaderboardMessage += '```ini\n';
        leaderboardMessage += '[Hạng] [ID Người chơi] Tên'.padEnd(40) + ' | Cảnh Giới (Tổng Exp)'.padEnd(30) + ' | Linh Thạch | Đạo Lữ\n';
        leaderboardMessage += '-'.repeat(100) + '\n';

        for (let i = 0; i < pageUsers.length; i++) {
            const user = pageUsers[i];
            const rank = start + i + 1;
            const member = interaction.guild.members.cache.get(user.discordId);
            const username = member ? member.displayName.slice(0, 15) : `Không Rõ`;

            let partnerName = 'Độc thân';
            if (user.songTuPartnerId) {
                 const partnerMember = interaction.guild.members.cache.get(user.songTuPartnerId);
                 partnerName = partnerMember ? partnerMember.displayName.slice(0, 20) : 'Không Rõ';
            }

            const rankIdPart = `[${rank}] [${user.discordId}] ${username}`.padEnd(40);
            const realmPart = ` | ${user.name} (${user.cumulativeXp} Exp)`.padEnd(30);
            const lsPart = ` | ${user.linhThach}`.padEnd(12);

            leaderboardMessage += `${rankIdPart}${realmPart}${lsPart} | ${partnerName}\n`;
        }
        leaderboardMessage += '```';

        const currentUserRank = allUsers.findIndex(u => u.discordId === interaction.user.id) + 1;
        if (currentPage === 1 && currentUserRank > usersPerPage) {
             const currentUserData = allUsers[currentUserRank - 1];
             if (currentUserData) {
                 const member = interaction.guild.members.cache.get(currentUserData.discordId);
                 const username = member ? member.displayName : `Bạn`;
                 leaderboardMessage += `\n**Hạng của bạn:** [${currentUserRank}] ${username} - ${currentUserData.name} (${currentUserData.cumulativeXp} Exp)`;
             }
        }

        bxhPagesTracker.set(messageId, { ...pageData, currentPage });

        await interaction.update({
            content: leaderboardMessage,
            components: [
                new ActionRowBuilder().addComponents(
                    new ButtonBuilder()
                        .setCustomId(`bxh_prev`)
                        .setLabel('Trang trước')
                        .setStyle(ButtonStyle.Primary)
                        .setDisabled(currentPage === 1),
                    new ButtonBuilder()
                        .setCustomId(`bxh_next`)
                        .setLabel('Trang sau')
                        .setStyle(ButtonStyle.Primary)
                        .setDisabled(currentPage === totalPages)
                )
            ]
        });
        return;
    }


    if (action === 'songtuaccept' || action === 'songtudecline') {
        const targetUserId = customIdParts[1];
        const initiatorUserId = customIdParts[2];

        if (interaction.user.id !== targetUserId) {
            await interaction.reply({ content: 'Bạn không phải là người nhận lời mời song tu này!', flags: [64] });
            return;
        }

        let targetUserData = await getUserData(targetUserId);
        let initiatorUserData = await getUserData(initiatorUserId);

        if (!targetUserData.isWaitingForSongTuAccept || targetUserData.songTuInitiatorId !== initiatorUserId || targetUserData.songTuOfferMessageId !== interaction.message.id) {
            await interaction.reply({ content: 'Lời mời song tu này đã hết hạn hoặc không còn hiệu lực.', flags: [64] });
            try {
                if (interaction.message.components.length > 0) {
                    await interaction.message.edit({ components: [] });
                }
            } catch (e) {
                console.error("Lỗi khi xóa nút sau tương tác hết hạn:", e);
            }
            return;
        }

        const disabledRow = new ActionRowBuilder()
            .addComponents(
                new ButtonBuilder()
                    .setCustomId('songtuaccept_disabled')
                    .setLabel('Đồng ý')
                    .setStyle(ButtonStyle.Success)
                    .setDisabled(true),
                new ButtonBuilder()
                    .setCustomId('songtudecline_disabled')
                    .setLabel('Từ chối')
                    .setStyle(ButtonStyle.Danger)
                    .setDisabled(true)
            );
        await interaction.update({ components: [disabledRow] }); 

        if (action === 'songtuaccept') {
            if (targetUserData.songTuPartnerId || initiatorUserData.songTuPartnerId) {
                 await interaction.followUp({ content: 'Một trong hai bạn đã có đạo lữ song tu rồi, không thể song tu cùng lúc hai người!', flags: [64] });
                 targetUserData.isWaitingForSongTuAccept = false;
                 targetUserData.songTuInitiatorId = null;
                 targetUserData.songTuOfferTimestamp = 0;
                 targetUserData.songTuOfferMessageId = null;
                 await updateUserData(targetUserId, targetUserData);
                 return;
            }

            targetUserData.songTuPartnerId = initiatorUserId;
            initiatorUserData.songTuPartnerId = targetUserId;

            targetUserData.isWaitingForSongTuAccept = false;
            targetUserData.songTuInitiatorId = null;
            targetUserData.songTuOfferTimestamp = 0;
            targetUserData.songTuOfferMessageId = null;

            await updateUserData(targetUserId, targetUserData);
            await updateUserData(initiatorUserId, initiatorUserData);

            await interaction.channel.send(`Chúc mừng <@${initiatorUserId}> và <@${targetUserId}> đã chính thức trở thành **song tu đạo lữ** của nhau! ❤️`);
            console.log(`${initiatorUserId} và ${targetUserId} đã trở thành song tu đạo lữ.`);

        } else if (action === 'songtudecline') {
            targetUserData.isWaitingForSongTuAccept = false;
            targetUserData.songTuInitiatorId = null;
            targetUserData.songTuOfferTimestamp = 0;
            targetUserData.songTuOfferMessageId = null;
            await updateUserData(targetUserId, targetUserData);

            await interaction.channel.send(`<@${targetUserId}> đã từ chối yêu cầu song tu của <@${initiatorUserId}>.`);
            console.log(`${targetUserId} đã từ chối yêu cầu song tu từ ${initiatorUserId}.`);
        }
    }

    // SỬA LỖI: Thêm handler cho các nút hóa giải bùa
    if (action === 'dispel') {
        const typeToDispel = customIdParts[1]; // 'expblock' or 'breakreduce'
        const userId = customIdParts[2];

        if (interaction.user.id !== userId) {
            return interaction.reply({ content: 'Bạn không phải người dùng bùa này!', flags: [64] });
        }

        await interaction.deferUpdate(); // Acknowledge the interaction

        let userData = await getUserData(userId);
        const item = SHOP_ITEMS['05']; // Bùa Phá Giải

        if (userData.buaPhaGiaiItemCount < 1) {
            await interaction.followUp({ content: `Bạn không có ${item.name} nào trong túi!`, flags: [64] });
            return;
        }

        let dispelled = false;
        let messageReply = "";

        if (typeToDispel === 'expblock' && userData.activeExpBlockTalismans.length > 0) {
            userData.activeExpBlockTalismans.shift(); // Xóa 1 bùa
            messageReply = `Bạn đã hóa giải thành công 1 **Bùa Chặn Exp**.`;
            dispelled = true;
        } else if (typeToDispel === 'breakreduce' && userData.activeBreakthroughReduceTalismans.length > 0) {
            userData.activeBreakthroughReduceTalismans.shift(); // Xóa 1 bùa
            messageReply = `Bạn đã hóa giải thành công 1 **Bùa Giảm Tỉ Lệ Đột Phá**.`;
            dispelled = true;
        }

        if (dispelled) {
            userData.buaPhaGiaiItemCount -= 1;
            await updateUserData(userId, userData);
            await interaction.editReply({ content: messageReply, components: [] });
        } else {
            await interaction.editReply({ content: 'Hiệu ứng bất lợi bạn chọn không còn tồn tại.', components: [] });
        }
    }	
});


client.on('messageCreate', async message => {
    if (message.author.bot || !message.guild) return;

    const userId = message.author.id;
    let userData = await getUserData(userId); 
    if (!userData) return; // Dừng nếu không lấy được dữ liệu user

    const now = Date.now();
    const lowerCaseContent = message.content.toLowerCase();
    const isSpecialChannel = SPECIAL_XP_CHANNEL_ID && message.channel.id === SPECIAL_XP_CHANNEL_ID;

    // Cập nhật lại thời gian hoạt động và reset cờ phạt không hoạt động
    userData.lastActivityTime = now;
    userData.inactivityNotified = false;

    // Process commands first
    if (lowerCaseContent.startsWith('!')) { 
        const args = message.content.slice(1).trim().split(/ +/);
        const commandWithId = args.shift().toLowerCase();
        // --- BẮT ĐẦU CÁC LỆNH NHẬP VAI ---

        // Lệnh !nhapvai
        if (commandWithId === 'nhapvai') {
            if (userData.rolePlaying?.isActive) {
                return message.reply('Bạn đã đang trong một cuộc phiêu lưu rồi! Dùng `!choilai` để bắt đầu lại.');
            }
            const modal = new ModalBuilder().setCustomId('nhapvai_setup_modal').setTitle('Tạo Nhân Vật Nhập Vai');
            const nameInput = new TextInputBuilder().setCustomId('char_name').setLabel("Tên nhân vật của bạn là gì?").setStyle(TextInputStyle.Short).setRequired(true);
            const backstoryInput = new TextInputBuilder().setCustomId('char_backstory').setLabel("Hãy viết một cốt truyện nền cho nhân vật").setStyle(TextInputStyle.Paragraph).setPlaceholder('Ví dụ: Là một kiếm sĩ vô danh đi tìm kẻ đã hại sư phụ...').setRequired(true);
            modal.addComponents(new ActionRowBuilder().addComponents(nameInput), new ActionRowBuilder().addComponents(backstoryInput));
            await message.showModal(modal);
            return;
        }

        // Lệnh !choilai
        if (commandWithId === 'choilai') {
            if (!userData.rolePlaying?.isActive) {
                return message.reply('Bạn không có cuộc phiêu lưu nào đang diễn ra để chơi lại!');
            }
            userData.rolePlaying = { isActive: false, characterName: null, storyHistory: [], lastChoices: [], currentMessageId: null, channelId: null };
            await updateUserData(userId, userData);
            await message.reply('Bạn đã kết thúc cuộc phiêu lưu. Giờ bạn có thể dùng `!nhapvai` để bắt đầu một cuộc đời mới!');
            return;
        }

        // Lệnh !tieptuc
        if (commandWithId === 'tieptuc') {
            if (!userData.rolePlaying?.isActive) {
                return message.reply('Bạn chưa có cuộc phiêu lưu nào để tiếp tục. Hãy dùng `!nhapvai` để bắt đầu!');
            }
            if (!userData.rolePlaying.currentMessageId || !userData.rolePlaying.channelId) {
                return message.reply('Không tìm thấy vị trí cuộc phiêu lưu. Vui lòng dùng `!choilai` để bắt đầu lại.');
            }
            const messageLink = `https://discord.com/channels/${message.guild.id}/${userData.rolePlaying.channelId}/${userData.rolePlaying.currentMessageId}`;
            const row = new ActionRowBuilder().addComponents(new ButtonBuilder().setLabel('Đi Đến Cuộc Phiêu Lưu').setStyle(ButtonStyle.Link).setURL(messageLink));
            await message.reply({ content: `Cuộc phiêu lưu của **${userData.rolePlaying.characterName}** đang chờ bạn!`, components: [row] });
            return;
        }
        // --- KẾT THÚC CÁC LỆNH NHẬP VAI ---

        // --- TG COMMAND ---
        if (commandWithId === 'tg') {
            if (!userData.hasStartedCultivation) {
                return message.reply({ content: 'Bạn cần nhập lệnh `!batdaututien` để bắt đầu con đường tu tiên trước!', flags: [64] });
            }

            const hasActiveExpBlock = userData.activeExpBlockTalismans.length > 0;
            const isUnderPunishment = userData.punishedUntil && now < userData.punishedUntil;
            const isStaminaDepleted = userData.level > 0 && userData.currentStamina <= 0;

            if (isUnderPunishment) {
                const remainingTimeMs = userData.punishedUntil - now;
                const remainingMinutes = Math.ceil(remainingTimeMs / (1000 * 60));
                return message.reply({ content: `⚡ **Đang bị trừng phạt:** Còn ${remainingMinutes} phút. Không thể nhận Exp/Linh Thạch.`, flags: [64] });
            }

            if (hasActiveExpBlock) {
                const oldestBlockTime = Math.min(...userData.activeExpBlockTalismans.map(bua => bua.endTime));
                const remainingTimeMs = oldestBlockTime - now;
                const remainingHours = Math.ceil(remainingTimeMs / (1000 * 60 * 60));
                return message.reply({ content: `🚫 **Bùa Chặn Exp:** Đang dính (còn ${remainingHours} giờ). Không thể nhận Exp/Linh Thạch.`, flags: [64] });
            }

            if (isStaminaDepleted) {
                return message.reply({ content: `💪 **Thể Lực:** Đã cạn kiệt! Không thể nhận Exp và Linh Thạch từ tin nhắn lúc này.`, flags: [64] });
            }

            let effectiveMessageCooldown = MESSAGE_COOLDOWN_SECONDS; 
            let effectiveLinhThachCooldown = LS_GAIN_COOLDOWN_SECONDS; 

            if (isSpecialChannel) {
                effectiveMessageCooldown = SPECIAL_CHANNEL_COOLDOWN_SECONDS;
                effectiveLinhThachCooldown = SPECIAL_LS_COOLDOWN_SECONDS;
            }

            if (userData.activeBoost && userData.activeBoost.type === SHOP_ITEMS['01'].name && now < userData.activeBoost.endTime) {
                effectiveMessageCooldown = userData.activeBoost.messageCooldownSeconds; 
            }

            if (userData.level > 0 && userData.currentStamina > 0 && userData.currentStamina <= (userData.maxStamina / 2)) {
                effectiveMessageCooldown = 180;
                effectiveLinhThachCooldown = 300;
            }

            const lastMessageTime = userLastMessageTime.get(userId) || 0;
            const timeSinceLastMessage = (now - lastMessageTime) / 1000;
            const remainingXPCooldown = Math.max(0, effectiveMessageCooldown - timeSinceLastMessage);

            const timeSinceLastLinhThachGain = (now - userData.lastLinhThachGainTime) / 1000;
            const remainingLTCooldown = Math.max(0, effectiveLinhThachCooldown - timeSinceLastLinhThachGain);

            let infoMessage = `__**Thông tin Cooldown của ${message.member.displayName}:**__\n\n`;
            infoMessage += `**Cooldown Linh Thạch (Tổng):** ${effectiveLinhThachCooldown} giây\n`;
            infoMessage += `**Cooldown còn lại Linh Thạch:** ${remainingLTCooldown.toFixed(0)} giây\n`;
            infoMessage += `**Cooldown Exp (Tổng):** ${effectiveMessageCooldown} giây\n`;
            infoMessage += `**Cooldown còn lại Exp:** ${remainingXPCooldown.toFixed(0)} giây`;

            await message.reply({ content: infoMessage, flags: [64] });
            await updateUserData(userId, userData); // Chỉ cập nhật lastActivityTime
            return;
        }

        // --- ADMIN COMMANDS ---
        if (commandWithId === 'taocode') {
            if (!ADMIN_ROLE_ID || !message.member.roles.cache.has(ADMIN_ROLE_ID)) {
                return message.reply('Bạn không có quyền sử dụng lệnh này.');
            }

            const [usesStr, ...rewardPairs] = args;

            const uses = parseInt(usesStr);
            if (isNaN(uses) || uses <= 0 || rewardPairs.length === 0) {
                 return message.reply('Sai cú pháp! Dùng: `!taocode <số_lần_dùng> <loại1>:<sl1> [loại2:sl2]...`\nVí dụ: `!taocode 10 exp:500 linhthach:100 02:5`');
            }

            const rewards = [];
            let rewardString = '';

            for (const pair of rewardPairs) {
                const [type, amountStr] = pair.split(':');
                if (!type || !amountStr) return message.reply(`Phần thưởng không hợp lệ: \`${pair}\`. Phải có dạng \`loại:số_lượng\`.`);

                const amount = parseInt(amountStr);
                if (isNaN(amount) || amount <= 0) return message.reply(`Số lượng cho \`${type}\` phải là một số dương.`);

                const rewardType = type.toLowerCase();
                 if (rewardType !== 'exp' && rewardType !== 'linhthach' && !SHOP_ITEMS[rewardType]) {
                    return message.reply(`Loại phần thưởng không hợp lệ: \`${rewardType}\`.`);
                }

                rewards.push({ type: rewardType, amount });

                let rewardName = SHOP_ITEMS[rewardType]?.name || rewardType;
                rewardString += `> • ${amount} ${rewardName}\n`;
            }


            const characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
            let newCode = '';
            for (let i = 0; i < GIFT_CODE_LENGTH; i++) {
                newCode += characters.charAt(Math.floor(Math.random() * characters.length));
            }

            const codeData = {
                code: newCode,
                rewards: rewards,
                usesLeft: uses,
                redeemedBy: [],
                createdAt: new Date(),
                createdBy: message.author.id
            };

            const codeDocRef = doc(db, `artifacts/${client.replitAppId}/public/data/discordBotGiftCodes`, newCode);
            await setDoc(codeDocRef, codeData);

            let replyMsg = `Đã tạo thành công giftcode **${newCode}**.\n`;
            replyMsg += `**Số lần dùng:** ${uses}\n`;
            replyMsg += `**Phần thưởng mỗi lần dùng:**\n${rewardString}`;

            await message.author.send(replyMsg).catch(() => message.reply('Không thể gửi DM cho bạn. Đây là code của bạn: `' + newCode + '`'));
            if(message.deletable) await message.delete().catch(console.error);
            return;
        }

        if (commandWithId === 'trungphat') {
            if (!PUNISH_ROLE_ID || !message.member.roles.cache.has(PUNISH_ROLE_ID)) {
                return message.reply('Bạn không có quyền hạn để sử dụng lệnh này.');
            }

            const targetMember = message.mentions.members.first();
            const durationString = args.find(arg => !arg.startsWith('<@'));

            if (!targetMember || !durationString) {
                return message.reply('Sai cú pháp! Dùng: `!trungphat <@người_dùng> <số_phút>`');
            }
            if (targetMember.id === message.author.id) {
                return message.reply('Bạn không thể tự trừng phạt chính mình!');
            }
            if (targetMember.user.bot) {
                return message.reply('Bạn không thể trừng phạt bot!');
            }

            const punishmentDurationMinutes = parseInt(durationString);
            if (isNaN(punishmentDurationMinutes) || punishmentDurationMinutes <= 0) {
                return message.reply('Thời gian trừng phạt phải là một số nguyên dương (tính bằng phút)!');
            }

            let targetUserData = await getUserData(targetMember.id);
            if (!targetUserData.hasStartedCultivation) {
                return message.reply(`${targetMember.displayName} chưa bắt đầu con đường tu tiên! Không thể trừng phạt.`);
            }

            targetUserData.punishedUntil = now + (punishmentDurationMinutes * 60 * 1000);
            targetUserData.punishedChannelId = message.channel.id;
            targetUserData.punishmentDurationMinutes = punishmentDurationMinutes;

            if (targetUserData.level > 0) {
                const staminaToDeduct = Math.ceil(targetUserData.currentStamina / 2);
                targetUserData.currentStamina = Math.max(0, targetUserData.currentStamina - staminaToDeduct);
            }

            await updateUserData(targetMember.id, targetUserData);
            if (message.deletable) await message.delete().catch(console.error);

            await message.channel.send(`Người chơi <@${targetMember.id}> đã bị Thiên Đạo của tiểu giới này giáng Lôi kiếp trừng phạt. Trong vòng **${punishmentDurationMinutes} phút** sẽ không nhận được exp và linh thạch, bị trừ một nửa thể lực.`);
            return;
        }

        if (commandWithId === 'huytrungphat') {
            if (!PUNISH_ROLE_ID || !message.member.roles.cache.has(PUNISH_ROLE_ID)) {
                return message.reply('Bạn không có quyền hạn để sử dụng lệnh này.');
            }

            const targetMember = message.mentions.members.first();
            if (!targetMember) {
                return message.reply('Vui lòng nhắc đến người bạn muốn gỡ bỏ trừng phạt! Cú pháp: `!huytrungphat <@người_dùng>`');
            }

            if (targetMember.user.bot) return message.reply('Bot không bị trừng phạt.');

            let targetUserData = await getUserData(targetMember.id);
            if (!targetUserData.punishedUntil || now >= targetUserData.punishedUntil) {
                return message.reply(`${targetMember.displayName} hiện không bị trừng phạt.`);
            }

            targetUserData.punishedUntil = null;
            targetUserData.punishedChannelId = null;
            targetUserData.punishmentDurationMinutes = null;

            await updateUserData(targetMember.id, targetUserData);
            if (message.deletable) await message.delete().catch(console.error);

            await message.channel.send(`Thiên Đạo của tiểu thế giới này lên tiếng: Ta tha cho <@${targetMember.id}> lần này. Đừng tái phạm!`);
            return;
        }

        if (commandWithId === 'ngaymoi') {
            if (!ADMIN_ROLE_ID || !message.member.roles.cache.has(ADMIN_ROLE_ID)) {
                return message.reply('Bạn không có quyền sử dụng lệnh này.');
            }
            await message.reply('Bắt đầu quá trình reset dữ liệu hàng ngày cho toàn bộ người chơi...');
            await performDailyReset();
            await message.channel.send(`✅ Đã reset thành công dữ liệu hàng ngày bằng tay!`);
            return;
        }

        // =======================================================
        // --- LỆNH THÔNG BÁO (ANNOUNCEMENT COMMAND) ---
        // =======================================================
        if (commandWithId === 'thongbao') {
            // 1. Kiểm tra quyền Admin
            if (!ADMIN_ROLE_ID || !message.member.roles.cache.has(ADMIN_ROLE_ID)) {
                return message.reply('Bạn không có quyền sử dụng lệnh này.');
            }

            // 2. Lấy nội dung thông báo từ các đối số (args)
            const announcementContent = args.join(' ');

            // 3. Kiểm tra xem có nội dung không
            if (!announcementContent) {
                return message.reply('Vui lòng nhập nội dung bạn muốn thông báo. Cú pháp: `!thongbao <nội dung>`');
            }

            // 4. Xóa tin nhắn lệnh gốc của người dùng
            if (message.deletable) {
                await message.delete().catch(console.error);
            }

            // 5. Gửi thông báo vào kênh hiện tại
            try {
                await message.channel.send(announcementContent);
            } catch (error) {
                console.error("Lỗi khi gửi thông báo:", error);
                // Gửi tin nhắn riêng cho admin nếu có lỗi
                await message.author.send(`Không thể gửi thông báo của bạn vào kênh ${message.channel}. Vui lòng kiểm tra lại quyền của bot trong kênh đó.`).catch(() => {});
            }

             // Dừng xử lý các lệnh khác
             return;
        }

        // =======================================================
        // --- LỆNH ADMIN TỔNG HỢP (GAME MASTER COMMAND) ---
        // =======================================================
        if (commandWithId === 'gm') {
            // 1. Kiểm tra quyền Admin
            if (!ADMIN_ROLE_ID || !message.member.roles.cache.has(ADMIN_ROLE_ID)) {
                return message.reply('Bạn không có quyền sử dụng lệnh này.');
            }

            // 2. Phân tích cú pháp lệnh
            const targetMember = message.mentions.members.first();
            const type = args[1]?.toLowerCase();
            const action = args[2]?.toLowerCase();
            const valueStr = args[3];
            const unitOrDurationStr = args[4];

            const usageHelp = 'Sai cú pháp! Ví dụ:\n' +
                '```' +
                '!gm <@user> exp <add|sub> <số lượng>\n' +
                '!gm <@user> lt <add|sub> <số lượng>\n' +
                '!gm <@user> theluc <set|add|sub> <số lượng>\n' +
                '!gm <@user> effect clear\n'+
                '!gm <@user> effect <loại> <add|addtime|subtime> <số> [đơn vị]\n' +
                '```\n' +
                '**Chi tiết `effect`:**\n' +
                '`!gm <@user> effect <loại> add <số_lượng> [thời_gian_h/mặc_định]`\n' +
                '   - `loại`: buachanexp, giamdotpha, x2exp\n' +
                '`!gm <@user> effect <loại> <addtime|subtime> <số> <gio|phut>`\n' +
                '   - `loại`: buachanexp, giamdotpha, x2exp, punish';


            if (!targetMember || !type || !action) {
                // Khi sai cú pháp, trả lời tạm thời để không làm bẩn kênh
                return message.reply({ content: usageHelp, flags: [64] });
            }
             if (targetMember.user.bot) {
                return message.reply({ content: 'Không thể tác động lên bot.', flags: [64] });
            }

            // 3. Lấy dữ liệu người chơi mục tiêu
            let targetUserData = await getUserData(targetMember.id);
            if (!targetUserData || !targetUserData.hasStartedCultivation) {
                return message.reply({ content: `${targetMember.displayName} chưa bắt đầu tu tiên hoặc không tìm thấy dữ liệu.`, flags: [64] });
            }

            let replyMessage = `Thực hiện lệnh lên ${targetMember.displayName}:\n`;
            const value = parseInt(valueStr);

            // 4. Xử lý logic theo từng loại (Giữ nguyên không thay đổi)
            switch (type) {
                case 'exp':
                    if (isNaN(value) || value <= 0) return message.reply({ content: 'Giá trị Exp phải là một số dương.', flags: [64] });
                    if (action === 'add') {
                        targetUserData.xp += value;
                        targetUserData.cumulativeXp += value;
                        replyMessage += `> Đã cộng **${value} Exp**.`;
                    } else if (action === 'sub') {
                        const originalXp = targetUserData.cumulativeXp;
                        targetUserData.xp = Math.max(0, targetUserData.xp - value);
                        targetUserData.cumulativeXp = Math.max(0, targetUserData.cumulativeXp - value);
                        replyMessage += `> Đã trừ **${originalXp - targetUserData.cumulativeXp} Exp**.`;
                    } else {
                        return message.reply({ content: usageHelp, flags: [64] });
                    }
                    break;

                case 'lt': // Linh Thạch
                    if (isNaN(value) || value <= 0) return message.reply({ content: 'Giá trị Linh Thạch phải là một số dương.', flags: [64] });
                    if (action === 'add') {
                        targetUserData.linhThach += value;
                        replyMessage += `> Đã cộng **${value} Linh Thạch**.`;
                    } else if (action === 'sub') {
                        targetUserData.linhThach = Math.max(0, targetUserData.linhThach - value);
                        replyMessage += `> Đã trừ **${value} Linh Thạch**.`;
                    } else {
                        return message.reply({ content: usageHelp, flags: [64] });
                    }
                    break;

                case 'theluc': // Thể Lực
                     if (isNaN(value)) return message.reply({ content: 'Giá trị Thể Lực phải là một số.', flags: [64] });
                     if (targetUserData.level === 0) return message.reply({ content: 'Phàm nhân không có thể lực.', flags: [64] });

                     if (action === 'set') {
                         targetUserData.currentStamina = Math.max(0, Math.min(value, targetUserData.maxStamina));
                         replyMessage += `> Đã thiết lập Thể Lực thành **${targetUserData.currentStamina}/${targetUserData.maxStamina}**.`;
                     } else if (action === 'add') {
                         targetUserData.currentStamina = Math.min(targetUserData.maxStamina, targetUserData.currentStamina + value);
                         replyMessage += `> Đã cộng **${value} Thể Lực**. Hiện tại: **${targetUserData.currentStamina}/${targetUserData.maxStamina}**.`;
                     } else if (action === 'sub') {
                         targetUserData.currentStamina = Math.max(0, targetUserData.currentStamina - value);
                         replyMessage += `> Đã trừ **${value} Thể Lực**. Hiện tại: **${targetUserData.currentStamina}/${targetUserData.maxStamina}**.`;
                     } else {
                        return message.reply({ content: usageHelp, flags: [64] });
                    }
                    break;

                case 'effect':
                    const effectType = action; 
                    const effectAction = valueStr;
                    const effectValue = parseInt(args[4]);
                    const effectUnit = args[5]?.toLowerCase();

                    if (effectType === 'clear') {
                        targetUserData.activeBoost = { type: null, endTime: null, messageCooldownSeconds: null, xpMultiplier: null };
                        targetUserData.activeExpBlockTalismans = [];
                        targetUserData.activeBreakthroughReduceTalismans = [];
                        targetUserData.punishedUntil = null;
                        targetUserData.spamPunishedUntil = null;
                        replyMessage += `> Đã hóa giải **TOÀN BỘ** hiệu ứng bất lợi và buff.`;
                        break; 
                    }

                    if (!effectAction || isNaN(effectValue) || effectValue <= 0) {
                        return message.reply({ content: usageHelp, flags: [64] });
                    }

                    if (effectAction === 'addtime' || effectAction === 'subtime') {
                        if (effectUnit !== 'gio' && effectUnit !== 'phut') {
                            return message.reply({ content: 'Đơn vị thời gian không hợp lệ. Chỉ chấp nhận `gio` hoặc `phut`.', flags: [64] });
                        }

                        let timeMs = (effectUnit === 'gio') ? (effectValue * 3600000) : (effectValue * 60000);
                        const modifier = (effectAction === 'addtime' ? 1 : -1);
                        const actionText = (effectAction === 'addtime' ? 'cộng thêm' : 'trừ đi');

                        switch (effectType) {
                            case 'buachanexp':
                                if (targetUserData.activeExpBlockTalismans.length === 0) return message.reply({ content: 'Người dùng không bị ảnh hưởng bởi Bùa Chặn Exp.', flags: [64] });
                                targetUserData.activeExpBlockTalismans.sort((a, b) => a.endTime - b.endTime);
                                targetUserData.activeExpBlockTalismans[0].endTime += timeMs * modifier;
                                if (targetUserData.activeExpBlockTalismans[0].endTime <= Date.now()) {
                                    targetUserData.activeExpBlockTalismans.shift();
                                    replyMessage += `> Đã **xóa** 1 Bùa Chặn Exp.`;
                                } else {
                                    replyMessage += `> Đã **${actionText} ${effectValue} ${effectUnit}** cho Bùa Chặn Exp.`;
                                }
                                break;
                            case 'giamdotpha':
                                if (targetUserData.activeBreakthroughReduceTalismans.length === 0) return message.reply({ content: 'Người dùng không bị ảnh hưởng bởi Bùa Giảm Tỉ Lệ.', flags: [64] });
                                targetUserData.activeBreakthroughReduceTalismans.sort((a, b) => a.endTime - b.endTime);
                                targetUserData.activeBreakthroughReduceTalismans[0].endTime += timeMs * modifier;
                                if (targetUserData.activeBreakthroughReduceTalismans[0].endTime <= Date.now()) {
                                    targetUserData.activeBreakthroughReduceTalismans.shift();
                                    replyMessage += `> Đã **xóa** 1 Bùa Giảm Tỉ Lệ.`;
                                } else {
                                    replyMessage += `> Đã **${actionText} ${effectValue} ${effectUnit}** cho Bùa Giảm Tỉ Lệ.`;
                                }
                                break;
                            case 'x2exp':
                                if (!targetUserData.activeBoost || targetUserData.activeBoost.endTime <= Date.now()) return message.reply({ content: 'Người dùng không có hiệu ứng X2 Exp.', flags: [64] });
                                targetUserData.activeBoost.endTime += timeMs * modifier;
                                if (targetUserData.activeBoost.endTime <= Date.now()) {
                                    targetUserData.activeBoost = { type: null, endTime: null, messageCooldownSeconds: null, xpMultiplier: null };
                                    replyMessage += `> Đã **xóa** hiệu ứng X2 Exp.`;
                                } else {
                                    replyMessage += `> Đã **${actionText} ${effectValue} ${effectUnit}** cho hiệu ứng X2 Exp.`;
                                }
                                break;
                            case 'punish':
                                if (!targetUserData.punishedUntil || targetUserData.punishedUntil <= Date.now()) return message.reply({ content: 'Người dùng không đang bị trừng phạt.', flags: [64] });
                                targetUserData.punishedUntil += timeMs * modifier;
                                if (targetUserData.punishedUntil <= Date.now()) {
                                    targetUserData.punishedUntil = null;
                                    replyMessage += `> Đã **gỡ bỏ** trừng phạt.`;
                                } else {
                                    replyMessage += `> Đã **${actionText} ${effectValue} ${effectUnit}** cho thời gian trừng phạt.`;
                                }
                                break;
                            default:
                                return message.reply({ content: usageHelp, flags: [64] });
                        }
                    } 
                    else if (effectAction === 'add') {
                        const durationStr = args[5];
                        switch (effectType) {
                             case 'buachanexp':
                                const stacks_bce = effectValue;
                                const durationHours_bce = parseInt(durationStr) || 10;
                                for(let i=0; i < stacks_bce; i++) {
                                    targetUserData.activeExpBlockTalismans.push({ endTime: Date.now() + (durationHours_bce * 3600000) });
                                }
                                replyMessage += `> Đã thêm **${stacks_bce} Bùa Chặn Exp** trong **${durationHours_bce} giờ**.`;
                                break;
                            case 'giamdotpha':
                                const stacks_gdp = effectValue;
                                const durationHours_gdp = parseInt(durationStr) || 72;
                                for(let i=0; i < stacks_gdp; i++) {
                                     if(targetUserData.activeBreakthroughReduceTalismans.length < SHOP_ITEMS['04'].maxStacks) {
                                         targetUserData.activeBreakthroughReduceTalismans.push({ endTime: Date.now() + (durationHours_gdp * 3600000) });
                                     }
                                }
                                replyMessage += `> Đã thêm **${stacks_gdp} Bùa Giảm Tỉ Lệ Đột Phá** trong **${durationHours_gdp} giờ**.`;
                                break;
                            case 'x2exp':
                                const durationMinutes_x2 = effectValue;
                                const item = SHOP_ITEMS['01'];
                                targetUserData.activeBoost = { type: item.name, endTime: Date.now() + (durationMinutes_x2 * 60000), messageCooldownSeconds: item.messageCooldownSeconds, xpMultiplier: item.xpMultiplier };
                                replyMessage += `> Đã thêm hiệu ứng **${item.name}** trong **${durationMinutes_x2} phút**.`;
                                break;
                            default:
                                return message.reply({ content: usageHelp, flags: [64] });
                        }
                    } else {
                        return message.reply({ content: usageHelp, flags: [64] });
                    }
                    break;

                default:
                    return message.reply({ content: usageHelp, flags: [64] });
            }

            // 5. Cập nhật dữ liệu, gửi DM và xóa lệnh gốc
            await updateUserData(targetMember.id, targetUserData);

            // Cố gắng gửi tin nhắn riêng (DM) cho admin
            await message.author.send(replyMessage).catch(err => {
                console.error(`Không thể gửi DM cho admin ${message.author.tag}. Lỗi:`, err);
                // Bạn có thể giữ im lặng hoặc gửi một tin nhắn lỗi tạm thời trong kênh nếu muốn
                // message.channel.send({ content: `Không thể gửi DM cho bạn, vui lòng kiểm tra cài đặt quyền riêng tư.`, flags: [64] });
            });

            // Xóa tin nhắn lệnh gốc của admin khỏi kênh chat
            if(message.deletable) {
                await message.delete().catch(console.error);
            }

            return;
        }

        // --- USER COMMANDS ---
        if (commandWithId === 'songtu') {
            if (!userData.hasStartedCultivation) {
                return message.reply('Bạn cần nhập lệnh `!batdaututien` để bắt đầu con đường tu tiên trước khi tìm đạo lữ!');
            }
            if (userData.songTuPartnerId) {
                return message.reply('Bạn đã có song tu đạo lữ rồi, không thể yêu cầu thêm!');
            }
            if (userData.isWaitingForSongTuAccept) {
                return message.reply('Bạn đang có một lời mời song tu đang chờ xử lý, không thể gửi yêu cầu khác!');
            }

            const targetMember = message.mentions.members.first();
            if (!targetMember) {
                return message.reply('Vui lòng nhắc đến người bạn muốn song tu cùng! Cú pháp: `!songtu <@user>`');
            }
            if (targetMember.id === userId) {
                return message.reply('Bạn không thể song tu với chính mình!');
            }
            if (targetMember.user.bot) {
                return message.reply('Bạn không thể song tu với bot!');
            }

            let targetUserData = await getUserData(targetMember.id);
            if (!targetUserData.hasStartedCultivation) {
                return message.reply(`${targetMember.displayName} chưa bắt đầu con đường tu tiên!`);
            }
            if (targetUserData.songTuPartnerId) {
                return message.reply(`${targetMember.displayName} đã có song tu đạo lữ rồi!`);
            }
            if (targetUserData.isWaitingForSongTuAccept) {
                return message.reply(`${targetMember.displayName} đang có một lời mời song tu đang chờ xử lý.`);
            }

            const row = new ActionRowBuilder()
                .addComponents(
                    new ButtonBuilder()
                        .setCustomId(`songtuaccept_${targetMember.id}_${userId}`)
                        .setLabel('Đồng ý')
                        .setStyle(ButtonStyle.Success),
                    new ButtonBuilder()
                        .setCustomId(`songtudecline_${targetMember.id}_${userId}`)
                        .setLabel('Từ chối')
                        .setStyle(ButtonStyle.Danger),
                );

            const offerMessage = await message.channel.send({
                content: `<@${targetMember.id}>, <@${userId}> muốn mời bạn trở thành song tu đạo lữ! Bạn có đồng ý không? (Lời mời sẽ hết hạn sau ${SONGTU_OFFER_TIMEOUT_MS / 1000 / 60} phút)`,
                components: [row],
            });

            targetUserData.isWaitingForSongTuAccept = true;
            targetUserData.songTuInitiatorId = userId;
            targetUserData.songTuOfferTimestamp = now;
            targetUserData.songTuOfferMessageId = offerMessage.id; 
            await updateUserData(targetMember.id, targetUserData);
            await updateUserData(userId, userData);

            setTimeout(async () => {
                let currentTargetUserData = await getUserData(targetMember.id);
                if (currentTargetUserData.isWaitingForSongTuAccept && currentTargetUserData.songTuInitiatorId === userId && currentTargetUserData.songTuOfferMessageId === offerMessage.id) {
                    currentTargetUserData.isWaitingForSongTuAccept = false;
                    currentTargetUserData.songTuInitiatorId = null;
                    currentTargetUserData.songTuOfferTimestamp = 0;
                    currentTargetUserData.songTuOfferMessageId = null;
                    await updateUserData(targetMember.id, currentTargetUserData);

                    try {
                        const expiredRow = new ActionRowBuilder()
                            .addComponents(
                                new ButtonBuilder()
                                    .setCustomId('songtuaccept_expired')
                                    .setLabel('Đồng ý (Hết hạn)')
                                    .setStyle(ButtonStyle.Secondary)
                                    .setDisabled(true),
                                new ButtonBuilder()
                                    .setCustomId('songtudecline_expired')
                                    .setLabel('Từ chối (Hết hạn)')
                                    .setStyle(ButtonStyle.Secondary)
                                    .setDisabled(true)
                            );
                        await offerMessage.edit({ content: `Lời mời song tu từ <@${userId}> đến <@${targetMember.id}> đã hết hạn.`, components: [expiredRow] });
                    } catch (e) {
                        console.error("Lỗi khi cập nhật tin nhắn lời mời hết hạn:", e);
                    }
                    console.log(`Lời mời song tu từ ${userId} đến ${targetMember.id} đã hết hạn.`);
                }
            }, SONGTU_OFFER_TIMEOUT_MS);
            return;
        }

        if (commandWithId === 'knst') {
            if (!userData.hasStartedCultivation) {
                return message.reply('Bạn cần nhập lệnh `!batdaututien` để bắt đầu con đường tu tiên trước khi sử dụng kỹ năng song tu!');
            }
            if (!userData.songTuPartnerId) {
                return message.reply('Bạn chưa có song tu đạo lữ, không thể sử dụng kỹ năng song tu!');
            }
            if (userData.songTuSkillDailyUseCount >= 1) { 
                const penaltyXp = Math.floor(userData.cumulativeXp * KNST_PENALTY_PERCENT);
                userData.cumulativeXp = Math.max(0, userData.cumulativeXp - penaltyXp);
                // Cập nhật lại xp cảnh giới
                const oldLevelConfig = getLevelConfig(userData.level);
                userData.xp = userData.cumulativeXp - oldLevelConfig.xpNeeded;

                await updateUserData(userId, userData);
                // Lấy lại dữ liệu đã cập nhật để hiển thị chính xác
                const updatedUserData = await getUserData(userId);
                await message.reply(`Bạn đã sử dụng kỹ năng song tu quá số lần cho phép trong ngày! Bạn bị trừ **${penaltyXp} Exp** và cảnh giới hiện tại là **${updatedUserData.name}**.`);
                console.log(`Người dùng ${userId} bị trừ ${penaltyXp} Exp do dùng KNST quá số lần cho phép.`);

                try {
                    let partnerUserData = await getUserData(userData.songTuPartnerId);
                    const partnerPenaltyXp = Math.floor(partnerUserData.cumulativeXp * KNST_PENALTY_PERCENT);
                    partnerUserData.cumulativeXp = Math.max(0, partnerUserData.cumulativeXp - partnerPenaltyXp);
                    const partnerOldLevelConfig = getLevelConfig(partnerUserData.level);
                    partnerUserData.xp = partnerUserData.cumulativeXp - partnerOldLevelConfig.xpNeeded;

                    await updateUserData(userData.songTuPartnerId, partnerUserData);
                    const partnerMember = await message.guild.members.fetch(userData.songTuPartnerId);
                    if (partnerMember) {
                        const updatedPartnerData = await getUserData(userData.songTuPartnerId);
                        await partnerMember.send(`Bạn bị tác dụng phụ từ kỹ năng song tu do đạo lữ của bạn sử dụng quá số lần cho phép! Bạn bị trừ **${partnerPenaltyXp} Exp** và cảnh giới hiện tại là **${updatedPartnerData.name}**.`);
                    }
                    console.log(`Partner ${userData.songTuPartnerId} bị trừ ${partnerPenaltyXp} Exp do dùng KNST quá số lần cho phép.`);
                } catch (error) {
                    console.error(`Lỗi khi trừ XP của partner (${userData.songTuPartnerId}) sau tác dụng phụ KNST:`, error);
                }
                return;
            }

            const targetMember = message.mentions.members.first();
            if (!targetMember || targetMember.id !== userData.songTuPartnerId) {
                return message.reply('Vui lòng nhắc đúng song tu đạo lữ của bạn để sử dụng kỹ năng song tu.');
            }
            const knstContent = args.slice(1).join(' ').trim();
            if (knstContent.length < 5) {
                return message.reply('Nội dung tin nhắn kỹ năng song tu phải có ít nhất 5 ký tự.');
            }

            knstRequests.set(userId, {
                partnerId: userData.songTuPartnerId,
                content: knstContent,
                timestamp: now,
                channelId: message.channel.id 
            });

            const partnerId = userData.songTuPartnerId;
            const partnerKnstRequest = knstRequests.get(partnerId);

            if (partnerKnstRequest &&
                partnerKnstRequest.partnerId === userId && 
                partnerKnstRequest.content === knstContent && 
                partnerKnstRequest.channelId === message.channel.id &&
                (now - partnerKnstRequest.timestamp <= KNST_WINDOW_MS)) { 

                userData.songTuSkillActiveEndTime = now + KNST_BOOST_DURATION_MS;
                userData.songTuSkillDailyUseCount += 1;
                await updateUserData(userId, userData);

                let partnerUserData = await getUserData(partnerId);
                partnerUserData.songTuSkillActiveEndTime = now + KNST_BOOST_DURATION_MS;
                partnerUserData.songTuSkillDailyUseCount += 1;
                await updateUserData(partnerId, partnerUserData);

                knstRequests.delete(userId);
                knstRequests.delete(partnerId);

                const durationMinutes = KNST_BOOST_DURATION_MS / (60 * 1000);
                await message.channel.send(`Kỹ năng song tu đã kích hoạt cho <@${userId}> và <@${partnerId}>! Trong **${durationMinutes} phút** tới, Exp nhận được từ tin nhắn sẽ **nhân đôi**! ✨`);
                console.log(`Kỹ năng song tu kích hoạt cho ${userId} và ${partnerId}.`);

            } else {
                await message.reply(`Bạn đã yêu cầu kỹ năng song tu. Vui lòng chờ đạo lữ của bạn (<@${partnerId}>) dùng lệnh \`!knst @${message.author.username} ${knstContent}\` trong vòng **${KNST_WINDOW_MS / 1000} giây** để kích hoạt!`);
                console.log(`Người dùng ${userId} đã gửi yêu cầu KNST, đang chờ partner ${partnerId}.`);
                setTimeout(() => {
                    if (knstRequests.has(userId) && knstRequests.get(userId).timestamp === now) {
                        knstRequests.delete(userId);
                        console.log(`Yêu cầu KNST của ${userId} đã hết hạn.`);
                    }
                }, KNST_WINDOW_MS + 1000); 
            }
            await updateUserData(userId, userData);
            return;
        }

        if (commandWithId === 'huydaolu') {
            if (!userData.hasStartedCultivation) {
                return message.reply('Bạn cần nhập lệnh `!batdaututien` để bắt đầu con đường tu tiên trước khi hủy đạo lữ!');
            }
            if (!userData.songTuPartnerId) {
                return message.reply('Bạn đang độc thân, không có đạo lữ để hủy!');
            }

            const targetMember = message.mentions.members.first();
            if (!targetMember) {
                return message.reply('Vui lòng nhắc đến đạo lữ bạn muốn hủy. Cú pháp: `!huydaolu <@đạo_lữ>`');
            }
            if (targetMember.id === userId) {
                return message.reply('Bạn không thể hủy đạo lữ với chính mình.');
            }
            if (targetMember.id !== userData.songTuPartnerId) {
                return message.reply(`Người được nhắc đến không phải đạo lữ của bạn. Đạo lữ hiện tại của bạn là <@${userData.songTuPartnerId}>.`);
            }

            if (userData.linhThach < HUYDAOLU_COST) {
                return message.reply(`Bạn không đủ Linh Thạch để hủy đạo lữ. Bạn cần ${HUYDAOLU_COST} Linh Thạch, nhưng bạn chỉ có ${userData.linhThach} Linh Thạch.`);
            }

            userData.linhThach -= HUYDAOLU_COST; 
            const partnerId = userData.songTuPartnerId;
            userData.songTuPartnerId = null; 
            userData.songTuSkillActiveEndTime = 0; 

            let partnerUserData = await getUserData(partnerId);
            partnerUserData.songTuPartnerId = null; 
            partnerUserData.songTuSkillActiveEndTime = 0; 

            await updateUserData(userId, userData);
            await updateUserData(partnerId, partnerUserData);

            await message.channel.send(`**Thông báo!** <@${userId}> và <@${targetMember.id}> sẽ không còn là **song tu đạo lữ** của nhau nữa. Mối quan hệ đã chấm dứt! 💔`);
            console.log(`Người dùng ${userId} đã hủy đạo lữ với ${targetMember.id}.`);
            return;
        }
        if (commandWithId === 'bxh') {
            const allUsers = await getAllUserData();

            if (allUsers.length === 0) {
                return message.channel.send("Chưa có ai tham gia tu luyện! Hãy là người đầu tiên bắt đầu với lệnh `!batdaututien`.");
            }

            allUsers.sort((a, b) => b.cumulativeXp - a.cumulativeXp);

            const usersPerPage = 15;
            const totalPages = Math.ceil(allUsers.length / usersPerPage);
            let currentPage = 1;

            const generateLeaderboardPage = (page) => {
                const start = (page - 1) * usersPerPage;
                const end = start + usersPerPage;
                const pageUsers = allUsers.slice(start, end);

                let leaderboardMessage = `__**Bảng Xếp Hạng Tu Luyện (Trang ${page}/${totalPages})**__\n\n`;
                leaderboardMessage += '```ini\n';
                leaderboardMessage += '[Hạng] [ID Người chơi] Tên'.padEnd(40) + ' | Cảnh Giới (Tổng Exp)'.padEnd(30) + ' | Linh Thạch | Đạo Lữ\n';
                leaderboardMessage += '-'.repeat(100) + '\n';


                for (let i = 0; i < pageUsers.length; i++) {
                    const user = pageUsers[i];
                    const rank = start + i + 1;
                    const member = message.guild.members.cache.get(user.discordId);
                    const username = member ? member.displayName.slice(0, 15) : `Không Rõ`;

                    let partnerName = 'Độc thân';
                    if (user.songTuPartnerId) {
                        const partnerMember = message.guild.members.cache.get(user.songTuPartnerId);
                        partnerName = partnerMember ? partnerMember.displayName.slice(0, 20) : 'Không Rõ';
                    }

                    const rankIdPart = `[${rank}] [${user.discordId}] ${username}`.padEnd(40);
                    const realmPart = ` | ${user.name} (${user.cumulativeXp} Exp)`.padEnd(30);
                    const lsPart = ` | ${user.linhThach}`.padEnd(12);

                    leaderboardMessage += `${rankIdPart}${realmPart}${lsPart} | ${partnerName}\n`;
                }
                leaderboardMessage += '```';

                const currentUserRank = allUsers.findIndex(u => u.discordId === userId) + 1;
                if (page === 1 && currentUserRank > usersPerPage) {
                    const currentUserData = allUsers[currentUserRank - 1];
                    if (currentUserData) {
                        const member = message.guild.members.cache.get(currentUserData.discordId);
                        const username = member ? member.displayName : `Bạn`;
                        leaderboardMessage += `\n**Hạng của bạn:** [${currentUserRank}] ${username} - ${currentUserData.name} (${currentUserData.cumulativeXp} Exp)`;
                    }
                }
                return leaderboardMessage;
            };

            const sentMessage = await message.channel.send({
                content: generateLeaderboardPage(currentPage),
                components: [
                    new ActionRowBuilder().addComponents(
                        new ButtonBuilder()
                            .setCustomId(`bxh_prev`)
                            .setLabel('Trang trước')
                            .setStyle(ButtonStyle.Primary)
                            .setDisabled(currentPage === 1),
                        new ButtonBuilder()
                            .setCustomId(`bxh_next`)
                            .setLabel('Trang sau')
                            .setStyle(ButtonStyle.Primary)
                            .setDisabled(currentPage === totalPages || totalPages <= 1)
                    )
                ]
            });

            bxhDataTracker.set(sentMessage.id, allUsers);
            bxhPagesTracker.set(sentMessage.id, { currentPage, totalPages, usersPerPage });

            setTimeout(() => {
                bxhDataTracker.delete(sentMessage.id);
                bxhPagesTracker.delete(sentMessage.id);
                sentMessage.edit({components: []}).catch(()=>{});
            }, 15 * 60 * 1000); 

            return;
        }

        if (commandWithId === 'batdaututien') {
            if (userData.hasStartedCultivation) {
                return message.reply(`Bạn đã ở cảnh giới **${userData.name} trên con đường tu luyện**, không cần nhập lệnh này nữa!`);
            } 
            const newUserData = {
                level: 0,
                xp: 0,
                cumulativeXp: 0, 
                hasStartedCultivation: true, 
                lastActivityTime: now, 
                consecutiveMessages: 0,
                redeemedCodes: [], 
                danX2ExpItemCount: 0,
                activeBoost: { type: null, endTime: null, messageCooldownSeconds: null, xpMultiplier: null },
                linhThach: 0, 
                lastLinhThachGainTime: 0, 
                dailyLinhThachGained: 0,
                dailyDanX2ExpPurchases: 0, 
                dailyDanX2ExpUses: 0, 
                dailyBuaChanExpUses: 0,
                currentStamina: 0, 
                xpSinceLastStaminaDeduct: 0,
                danTheLucItemCount: 0, 
                songTuPartnerId: null, 
                songTuSkillLastUsed: 0,
                songTuSkillActiveEndTime: 0, 
                songTuSkillDailyUseCount: 0,
                isWaitingForSongTuAccept: false, 
                songTuInitiatorId: null,
                songTuOfferTimestamp: 0, 
                songTuOfferMessageId: null,
                buaChanExpItemCount: 0, 
                buaGiamTiLePhaItemCount: 0, 
                buaPhaGiaiItemCount: 0,
                activeExpBlockTalismans: [], 
                activeBreakthroughReduceTalismans: [],
                punishedUntil: null, 
                punishedChannelId: null, 
                punishmentDurationMinutes: null,
                spamPunishedUntil: null,
                hapTinhDaiPhapItemCount: 0, 
                learnedSkills: [], 
                skillCooldowns: {}
            };

            await updateUserData(userId, newUserData);
            await message.reply(`Chúc mừng! Bạn đã chính thức bước vào con đường tu tiên và cảnh giới hiện tại của bạn là **Phàm Nhân**!`);
            if (message.member) {
                 await updateUserRole(message.member, 0);
            }
            return;
        }

        if (commandWithId.startsWith('cp')) {
            const cpCommandMatch = commandWithId.match(/^cp(\d+)$/);
            if (cpCommandMatch) {
                const commandId = cpCommandMatch[1]; 
                const item = SHOP_ITEMS[commandId];

                if (!item || !item.skillName) return; 

                const skillId = item.skillName; 
                const cooldownDuration = 30 * 60 * 1000; 

                if (!userData.learnedSkills.includes(skillId)) {
                    await message.reply('Bạn chưa học công pháp này.');
                    return;
                }

                const lastUsed = userData.skillCooldowns?.[skillId] || 0;
                if (now - lastUsed < cooldownDuration) {
                    const remainingTime = Math.ceil((cooldownDuration - (now - lastUsed)) / 60000);
                    await message.reply(`Bạn cần chờ thêm ${remainingTime} phút nữa để có thể sử dụng công pháp này.`);
                    return;
                }

                const targetMember = message.mentions.members.first();
                if (!targetMember) {
                    await message.reply(`Vui lòng nhắc đến người bạn muốn thi triển công pháp lên! Cú pháp: \`!cp${commandId} <@người_dùng>\``);
                    return;
                }
                if (targetMember.id === userId) {
                    await message.reply('Bạn không thể tự dùng công pháp lên chính mình!');
                    return;
                }
                if (targetMember.user.bot) {
                    await message.reply('Bạn không thể dùng công pháp lên bot!');
                    return;
                }
                let targetUserData = await getUserData(targetMember.id);
                if (!targetUserData.hasStartedCultivation || targetUserData.level === 0) {
                    await message.reply('Công pháp không có hiệu quả với Phàm Nhân.');
                    return;
                }

                const userRealmIndex = LEVELS.findIndex(l => l.level === userData.level);
                const targetRealmIndex = LEVELS.findIndex(l => l.level === targetUserData.level);
                const realmDifference = targetRealmIndex - userRealmIndex;
                let linhThachCost = 0;

                if (realmDifference > 2) {
                    await message.reply('Đối phương có cảnh giới quá cao, công pháp không thể ảnh hưởng.');
                    return;
                }
                if (realmDifference === 2) linhThachCost = 10;
                else if (realmDifference === 1) linhThachCost = 6;
                else linhThachCost = 3;

                if (userData.linhThach < linhThachCost) {
                    await message.reply(`Bạn không đủ Linh Thạch để thi triển công pháp. Cần ${linhThachCost} Linh Thạch.`);
                    return;
                }

                userData.linhThach -= linhThachCost;
                if (!userData.skillCooldowns) userData.skillCooldowns = {};
                userData.skillCooldowns[skillId] = now;

                let staminaDrained = Math.min(targetUserData.currentStamina, 2);
                targetUserData.currentStamina -= staminaDrained;
                let remainingDrain = 2 - staminaDrained;

                let linhThachDrained = 0;
                let xpDrained = 0;

                if (remainingDrain > 0) {
                    linhThachDrained = Math.min(targetUserData.linhThach, remainingDrain);
                    targetUserData.linhThach -= linhThachDrained;
                    remainingDrain -= linhThachDrained;
                }
                if (remainingDrain > 0) {
                    xpDrained = Math.min(targetUserData.xp, remainingDrain);
                    targetUserData.xp -= xpDrained;
                    targetUserData.cumulativeXp = Math.max(0, targetUserData.cumulativeXp - xpDrained);
                }

                let stolenLinhThach = 0;
                let stealChance = 0;
                let stealAmount = 0;

                if (realmDifference <= 0) {
                    stealChance = 20;
                    stealAmount = 4;
                } else if (realmDifference === 1) {
                    stealChance = 15;
                    stealAmount = 8;
                } else if (realmDifference === 2) {
                    stealChance = 10;
                    stealAmount = 12;
                }

                if (Math.random() * 100 < stealChance) {
                    stolenLinhThach = Math.min(targetUserData.linhThach, stealAmount);
                    targetUserData.linhThach -= stolenLinhThach;
                    userData.linhThach += stolenLinhThach;
                }

                await updateUserData(userId, userData);
                await updateUserData(targetMember.id, targetUserData);

                let resultMessage = `<@${userId}> đã sử dụng **${item.name}** lên <@${targetMember.id}>!`;
                if (staminaDrained > 0) resultMessage += `\n> Đối phương bị hút **${staminaDrained}** điểm thể lực.`;
                if (linhThachDrained > 0) resultMessage += `\n> Do thể lực không đủ, đối phương bị hút thêm **${linhThachDrained}** Linh Thạch.`;
                if (xpDrained > 0) resultMessage += `\n> Do Linh Thạch không đủ, đối phương bị hút thêm **${xpDrained}** Exp.`;
                if (stolenLinhThach > 0) resultMessage += `\n> May mắn mỉm cười, bạn đã trộm được **${stolenLinhThach}** Linh Thạch của đối phương!`;

                await message.channel.send(resultMessage);
                return;
            }
        }

        if (commandWithId === 'code') {
            if (!userData.hasStartedCultivation) {
                return message.reply('Bạn cần `!batdaututien` trước khi đổi code!');
            }
            const codeString = args[0]?.toUpperCase();
            if (!codeString) {
                return message.reply('Vui lòng nhập mã code. Cú pháp: `!code [Mã Code]`');
            }

            if (userData.redeemedCodes.includes(codeString)) {
                return message.reply('Bạn đã đổi mã code này rồi!');
            }

            const codeData = await getGiftCode(codeString);
            if (!codeData || codeData.usesLeft <= 0) {
                return message.reply('Mã code không tồn tại hoặc đã được sử dụng hết!');
            }
            if (codeData.redeemedBy && codeData.redeemedBy.includes(userId)) {
                return message.reply('Bạn đã đổi mã code này rồi!');
            }

            let rewardMessage = 'bạn nhận được:\n';
            for (const reward of codeData.rewards) {
                switch (reward.type) {
                    case 'exp':
                        userData.xp += reward.amount;
                        userData.cumulativeXp += reward.amount;
                        rewardMessage += `> • **${reward.amount} Exp**\n`;
                        break;
                    case 'linhthach':
                        userData.linhThach += reward.amount;
                        rewardMessage += `> • **${reward.amount} Linh Thạch**\n`;
                        break;
                    default: 
                        const item = SHOP_ITEMS[reward.type];
                        if (item) {
                            userData[item.itemCountField] = (userData[item.itemCountField] || 0) + reward.amount;
                            rewardMessage += `> • **${reward.amount} ${item.name}**\n`;
                        }
                        break;
                }
            }

            codeData.usesLeft -= 1;
            codeData.redeemedBy.push(userId);
            const codeDocRef = doc(db, `artifacts/${client.replitAppId}/public/data/discordBotGiftCodes`, codeString);
            await setDoc(codeDocRef, codeData, { merge: true });

            userData.redeemedCodes.push(codeString);
            await updateUserData(userId, userData);

            return message.reply(`Đổi code **${codeString}** thành công, ${rewardMessage}`);
        }

        // --- ALL OTHER COMMANDS ---

        if (commandWithId === 'kn') {
             if (!userData.hasStartedCultivation) {
                return message.reply('Bạn cần nhập lệnh `!batdaututien` để bắt đầu con đường tu tiên trước khi kiểm tra kinh nghiệm!');
            }

            const dailyCap = getDailyLinhThachCap(userData.level);
            const nextLevelConfig = getNextLevelConfig(userData.level);
            const xpForNextLevel = nextLevelConfig ? nextLevelConfig.xpNeeded : 'MAX';

            let infoMessage = `__**Thông tin tu luyện của ${message.member.displayName}:**__\n\n`;
            infoMessage += `🏮 **Cảnh giới hiện tại:** ${userData.name}\n`;
            infoMessage += `⚡ **Kinh nghiệm cảnh giới:** ${Math.floor(userData.xp)} / ${xpForNextLevel} Exp\n`;
            infoMessage += `📈 **Tổng kinh nghiệm tích lũy:** ${Math.floor(userData.cumulativeXp)} Exp\n`;
            infoMessage += `💎 **Linh Thạch:** ${userData.linhThach}\n`;
            infoMessage += `💰 **Linh Thạch đã nhận hôm nay:** ${userData.dailyLinhThachGained} / ${dailyCap}\n`;

            if (userData.level > 0) {
                infoMessage += `💪 **Thể Lực:** ${userData.currentStamina}/${userData.maxStamina}\n`;
            }

            if (nextLevelConfig) {
                const xpNeeded = nextLevelConfig.xpNeeded - userData.xp;
                infoMessage += `🎯 **Cảnh giới tiếp theo:** ${nextLevelConfig.name} (cần thêm ${Math.ceil(xpNeeded)} Exp)\n`;

                let effectiveChance = nextLevelConfig.breakthroughChance;
                let reductionInfo = "";
                if (userData.activeBreakthroughReduceTalismans.length > 0) {
                    const totalReduction = userData.activeBreakthroughReduceTalismans.length * SHOP_ITEMS['04'].reductionPercent;
                    effectiveChance = Math.max(0, nextLevelConfig.breakthroughChance - totalReduction);
                    reductionInfo = ` (Hiệu quả: ${effectiveChance}% do dính bùa)`;
                }
                 infoMessage += `🎲 **Tỉ lệ đột phá:** ${nextLevelConfig.breakthroughChance}%${reductionInfo}\n`;
            } else {
                infoMessage += `🏆 **Bạn đã đạt cảnh giới cao nhất!**\n`;
            }

            if (userData.songTuPartnerId) {
                try {
                    const partner = await message.guild.members.fetch(userData.songTuPartnerId);
                    infoMessage += `💕 **Song tu đạo lữ:** ${partner.displayName}\n`;
                } catch (e) {
                    infoMessage += `💕 **Song tu đạo lữ:** ID: ${userData.songTuPartnerId}\n`;
                }
            } else {
                infoMessage += `💔 **Trạng thái:** Độc thân\n`;
            }

            if (Object.values(userData).some(val => typeof val === 'number' && val > 0 && Object.values(SHOP_ITEMS).some(item => item.itemCountField && userData[item.itemCountField] > 0))) {
                infoMessage += `\n📦 **Vật phẩm:**\n`;
                for(const key in SHOP_ITEMS){
                    const item = SHOP_ITEMS[key];
                    if(userData[item.itemCountField] > 0){
                         infoMessage += `• ${item.name}: ${userData[item.itemCountField]}\n`;
                    }
                }
            }

            if (userData.learnedSkills && userData.learnedSkills.length > 0) {
                infoMessage += `\n📜 **Công pháp đã học:**\n`;
                userData.learnedSkills.forEach(skillId => {
                    const skillItem = Object.values(SHOP_ITEMS).find(item => item.skillName === skillId);
                    if (skillItem) {
                        infoMessage += `• ${skillItem.name}\n`;
                    }
                });
            }

            if (userData.activeBoost && now < userData.activeBoost.endTime) {
                const remainingTime = Math.ceil((userData.activeBoost.endTime - now) / 1000);
                infoMessage += `\n✨ **Hiệu ứng tăng cường:** ${userData.activeBoost.type} (còn ${remainingTime} giây)\n`;
            }

            if (userData.songTuSkillActiveEndTime > now) {
                const remainingTime = Math.ceil((userData.songTuSkillActiveEndTime - now) / 1000);
                infoMessage += `\n🌟 **Kỹ năng song tu:** Đang hoạt động (còn ${remainingTime} giây)\n`;
            }
             if (userData.activeExpBlockTalismans.length > 0) {
                const oldestBlockTime = Math.min(...userData.activeExpBlockTalismans.map(bua => bua.endTime));
                const remainingTimeMs = oldestBlockTime - now;
                const remainingHours = Math.ceil(remainingTimeMs / (1000 * 60 * 60));
                infoMessage += `\n🚫 **Bùa Chặn Exp:** Đang dính (còn ${remainingHours} giờ)\n`;
            }

            if (userData.activeBreakthroughReduceTalismans.length > 0) {
                const oldestReduceTime = Math.min(...userData.activeBreakthroughReduceTalismans.map(bua => bua.endTime));
                const remainingTimeMs = oldestReduceTime - now;
                const remainingHours = Math.ceil(remainingTimeMs / (1000 * 60 * 60));
                const totalReduction = userData.activeBreakthroughReduceTalismans.length * SHOP_ITEMS['04'].reductionPercent;
                infoMessage += `\n📉 **Bùa Giảm Tỉ Lệ Đột Phá:** ${userData.activeBreakthroughReduceTalismans.length} bùa (-${totalReduction}%, còn ${remainingHours} giờ)\n`;
            }

            if (userData.punishedUntil && now < userData.punishedUntil) {
                const remainingTimeMs = userData.punishedUntil - now;
                const remainingMinutes = Math.ceil(remainingTimeMs / (1000 * 60));
                infoMessage += `\n⚡ **Đang bị trừng phạt:** Còn ${remainingMinutes} phút (không nhận Exp/Linh Thạch)\n`;
            }

            await message.channel.send(infoMessage);
            await updateUserData(userId, userData);
            return;
        }

        if (commandWithId === 'tuvi') {
            let levelListMessage = `__**Danh sách Cảnh Giới và Kinh nghiệm yêu cầu:**__\n\n`;
            levelListMessage += '```ini\n';
            levelListMessage += '[Cảnh Giới] - Exp Cần Cho Giai Đoạn - Tỷ Lệ Đột Phá - Thể Lực Tối Đa\n'; 
            levelListMessage += '---------------------------------------------------------------------------------------\n'; 

            LEVELS.forEach(levelInfo => {
                if(levelInfo.level === 0) return; // Bỏ qua Phàm Nhân
                const staminaDisplay = levelInfo.maxStamina > 0 ? `${levelInfo.maxStamina}` : 'Không'; 
                levelListMessage += `[${levelInfo.name}] - ${levelInfo.xpNeeded} Exp (${levelInfo.breakthroughChance}%) - ${staminaDisplay}\n`; 
            });
            levelListMessage += '```\n';
            levelListMessage += `_Bạn có thể dùng lệnh \`!kn\` để xem kinh nghiệm hiện tại của mình._`;

            await message.channel.send({ content: levelListMessage });
            await updateUserData(userId, userData);
            return; 
        }

        if (commandWithId === 'dslenh') {
            const initialPageIndex = 0;
            const firstPage = DSL_PAGES[initialPageIndex];

            firstPage.title = firstPage.title.replace(/\(Trang \d+\/\d+\)/, `(Trang ${initialPageIndex + 1}/${DSL_PAGES.length})`);

            const row = new ActionRowBuilder()
                .addComponents(
                    new ButtonBuilder()
                        .setCustomId('dsl_prev')
                        .setLabel('Trang trước')
                        .setStyle(ButtonStyle.Primary)
                        .setDisabled(true), 
                    new ButtonBuilder()
                        .setCustomId('dsl_next')
                        .setLabel('Trang kế tiếp')
                        .setStyle(ButtonStyle.Primary)
                        .setDisabled(DSL_PAGES.length <= 1), 
                );

            try {
                const sentMessage = await message.channel.send({
                    content: `${firstPage.title}\n${firstPage.content}`,
                    components: [row]
                });
                dslPagesTracker.set(sentMessage.id, initialPageIndex);
            } catch (error) {
                console.error(`[LỖI !dslenh] Lỗi khi xử lý lệnh !dslenh cho ${message.author.tag}:`, error); 
                await message.channel.send(`Đã xảy ra lỗi khi cố gắng hiển thị danh sách lệnh. Vui lòng thử lại sau.`);
            }

            await updateUserData(userId, userData);
            return; 
        }

        if (commandWithId === 'ch') {
            let shopMessage = `__**Cửa hàng Chư Thiên Vạn Giới**__\n\n`;
            shopMessage += '```ini\n';
            shopMessage += '[ID] [Vật phẩm] - Mô tả - Giá\n'; 
            shopMessage += '-------------------------------------------\n';

            for (const itemId in SHOP_ITEMS) {
                const item = SHOP_ITEMS[itemId];
                shopMessage += `[${itemId}] ${item.name} - ${item.description} - Giá: ${item.price} Linh Thạch.\n`;
            }

            shopMessage += '```\n';
            shopMessage += `_Bạn có **${userData.linhThach} Linh Thạch** trong túi._\n`; 
            shopMessage += `_Sử dụng lệnh \`!mua<ID> <số lượng>\` để mua và \`!dung<ID> <số lượng>\` để sử dụng vật phẩm._\n`; 
            shopMessage += `_Ví dụ: \`!mua02 5\` để mua 5 Đan Thể Lực._`;

            await message.channel.send(shopMessage);
            await updateUserData(userId, userData);
            return;
        }

        const muaMatch = commandWithId.match(/^mua(\d+)$/);
        if (muaMatch) {
            if (!userData.hasStartedCultivation) {
                return message.reply('Bạn cần nhập lệnh `!batdaututien` để bắt đầu con đường tu tiên trước khi mua vật phẩm!');
            }
            const itemId = muaMatch[1];
            let quantity = 1; 
            if (args.length > 0) { 
                const parsedQuantity = parseInt(args[0]);
                if (isNaN(parsedQuantity) || parsedQuantity <= 0) {
                    return message.reply('Số lượng mua phải là một số dương. Vui lòng kiểm tra lại.');
                }
                quantity = parsedQuantity;
            }

            const item = SHOP_ITEMS[itemId];
            if (!item) {
                return message.reply(`Vật phẩm với ID **${itemId}** không tồn tại trong cửa hàng.`);
            }

            const totalCost = item.price * quantity;
            if (userData.linhThach < totalCost) {
                return message.reply(`Bạn không đủ Linh Thạch để mua ${quantity} ${item.name}. Bạn cần ${totalCost} Linh Thạch, nhưng bạn chỉ có ${userData.linhThach} Linh Thạch.`);
            }

            if (item.dailyPurchaseCap && ((userData[item.dailyPurchaseCountField] || 0) + quantity > item.dailyPurchaseCap)) {
                return message.reply(`Bạn chỉ có thể mua tối đa ${item.dailyPurchaseCap} ${item.name} mỗi ngày. Bạn đã mua ${userData[item.dailyPurchaseCountField] || 0} hôm nay.`);
            }

            userData.linhThach -= totalCost; 
            userData[item.itemCountField] = (userData[item.itemCountField] || 0) + quantity; 

            if (item.dailyPurchaseCountField) { 
                userData[item.dailyPurchaseCountField] = (userData[item.dailyPurchaseCountField] || 0) + quantity; 
            }

            await updateUserData(userId, userData);
            await message.reply(`Bạn đã mua thành công **${quantity} ${item.name}** với giá ${totalCost} Linh Thạch! Bạn còn **${userData.linhThach} Linh Thạch** và có **${userData[item.itemCountField]} ${item.name}** trong túi.`);
            return;
        }

        const dungMatch = commandWithId.match(/^dung(\d+)$/);
        if (dungMatch) {
            if (!userData.hasStartedCultivation) {
                return message.reply({ content: 'Bạn cần nhập lệnh `!batdaututien` để bắt đầu!', flags: [64] });
            }
            const itemId = dungMatch[1];
            const item = SHOP_ITEMS[itemId];
            if (!item) {
                return message.reply(`Vật phẩm với ID **${itemId}** không tồn tại.`, { flags: [64] });
            }

            if (itemId === '05') { // Logic đặc biệt cho Bùa Phá Giải
                const hasExpBlock = userData.activeExpBlockTalismans.length > 0;
                const hasBreakReduce = userData.activeBreakthroughReduceTalismans.length > 0;

                if (!hasExpBlock && !hasBreakReduce) {
                    return message.reply({ content: 'Bạn không có hiệu ứng bất lợi nào để hóa giải!', flags: [64] });
                }
                 if (userData[item.itemCountField] < 1) {
                    return message.reply({ content: `Bạn không có đủ ${item.name} trong túi!`, flags: [64] });
                }

                if (hasExpBlock && hasBreakReduce) {
                    // Cả hai bùa đều có -> Hiển thị nút chọn
                    const row = new ActionRowBuilder().addComponents(
                        new ButtonBuilder()
                            .setCustomId(`dispel_expblock_${userId}`)
                            .setLabel(`Hóa giải Bùa Chặn Exp (${userData.activeExpBlockTalismans.length})`)
                            .setStyle(ButtonStyle.Secondary),
                        new ButtonBuilder()
                            .setCustomId(`dispel_breakreduce_${userId}`)
                            .setLabel(`Hóa giải Bùa Giảm Tỉ Lệ (${userData.activeBreakthroughReduceTalismans.length})`)
                            .setStyle(ButtonStyle.Secondary)
                    );
                    await message.reply({
                        content: `Bạn đang dính nhiều loại bùa. Vui lòng chọn loại muốn hóa giải (cần 1 ${item.name} cho mỗi lần giải):`,
                        components: [row],
                        flags: [64]
                    });
                } else {
                    // Chỉ có một loại bùa
                    let dispelled = false;
                    let replyMessage = "";
                    userData[item.itemCountField] -= 1; // Trừ bùa trước

                    if (hasExpBlock) {
                        userData.activeExpBlockTalismans.shift(); // Xóa 1 bùa
                        replyMessage = `Bạn đã dùng 1 ${item.name} và hóa giải thành công 1 **Bùa Chặn Exp**.`;
                        dispelled = true;
                    } else if (hasBreakReduce) {
                        userData.activeBreakthroughReduceTalismans.shift(); // Xóa 1 bùa
                        replyMessage = `Bạn đã dùng 1 ${item.name} và hóa giải thành công 1 **Bùa Giảm Tỉ Lệ Đột Phá**.`;
                        dispelled = true;
                    }

                    if(dispelled){
                        await updateUserData(userId, userData);
                        await message.reply({ content: replyMessage, flags: [64] });
                    } else {
                         // Hoàn lại bùa nếu có lỗi
                         userData[item.itemCountField] += 1;
                    }
                }
                return; // Kết thúc xử lý cho bùa 05
            }

            // SỬA LỖI: Khôi phục logic cho các vật phẩm !dung khác
            let quantity = 1;
            let targetMember = message.mentions.members.first();

            if (args.length > 0) {
                if(targetMember){ // Case: !dung03 5 @user
                     const parsedQuantity = parseInt(args[0]);
                     if(!isNaN(parsedQuantity) && parsedQuantity > 0){
                         quantity = parsedQuantity;
                     }
                } else { // Case: !dung02 5
                    const parsedQuantity = parseInt(args[0]);
                    if(!isNaN(parsedQuantity) && parsedQuantity > 0){
                         quantity = parsedQuantity;
                    } else {
                        targetMember = message.mentions.members.first() || await message.guild.members.fetch(args[0]).catch(() => null);
                    }
                }
            }

            const itemCount = userData[item.itemCountField] || 0;
            if (itemCount < quantity) {
                return message.reply(`Bạn không có đủ ${item.name} trong túi! Bạn chỉ có ${itemCount} cái, nhưng cần ${quantity} cái.`, { flags: [64] });
            }

            if (item.targetable && !targetMember) {
                return message.reply(`Vui lòng nhắc đến người bạn muốn sử dụng **${item.name}** lên! Cú pháp: \`!dung${itemId} <số lượng> <@người_dùng>\``, { flags: [64] });
            }
            if (!item.targetable && targetMember && !item.skillName) {
                return message.reply(`**${item.name}** là vật phẩm tự dùng, không thể dùng lên người khác!`, { flags: [64] });
            }

            userData[item.itemCountField] -= quantity;
            if (item.dailyUseCap && ((userData[item.dailyUseCountField] || 0) + quantity > item.dailyUseCap)) {
                userData[item.itemCountField] += quantity; // Refund
                return message.reply(`Bạn chỉ có thể dùng tối đa ${item.dailyUseCap} ${item.name} mỗi ngày. Bạn đã dùng ${userData[item.dailyUseCountField] || 0} hôm nay.`, { flags: [64] });
            }

            if (item.dailyUseCountField) { 
                userData[item.dailyUseCountField] = (userData[item.dailyUseCountField] || 0) + quantity;
            }

            // Logic for each item
            switch (itemId) {
                case '01': { // Đan X2 Exp
                    if (userData.activeBoost && now < userData.activeBoost.endTime) {
                        await message.reply(`Bạn đang có một hiệu ứng tăng cường Exp đang hoạt động! Còn **${Math.ceil((userData.activeBoost.endTime - now) / 1000)} giây** nữa mới hết hiệu lực.`, { flags: [64] });
                        userData[item.itemCountField] += quantity; // Refund
                        if (item.dailyUseCountField) { userData[item.dailyUseCountField] -= quantity; }
                        await updateUserData(userId, userData);
                        return; 
                    }
                    userData.activeBoost = { type: item.name, endTime: now + (item.durationMs * quantity), messageCooldownSeconds: item.messageCooldownSeconds, xpMultiplier: item.xpMultiplier };
                    const durationMinutes = (item.durationMs * quantity) / 60000;
                    await message.reply(`Bạn đã sử dụng **${quantity} ${item.name}**! Exp nhận được sẽ **x2** trong **${durationMinutes} phút** tới!`);
                    break;
                }
                case '02': { // Đan Thể Lực
                    if (userData.level === 0) {
                        await message.reply(`Cảnh giới **Phàm Nhân** không cần dùng Đan Thể Lực.`, { flags: [64] });
                        userData[item.itemCountField] += quantity; // Refund
                        await updateUserData(userId, userData);
                        return;
                    }
                    const oldStamina = userData.currentStamina;
                    userData.currentStamina = Math.min(userData.maxStamina, userData.currentStamina + (item.staminaRecovery * quantity));
                    const recoveredAmount = userData.currentStamina - oldStamina; 
                    await message.reply(`Bạn đã sử dụng **${quantity} ${item.name}** và hồi phục **${recoveredAmount} Thể Lực**! Thể lực hiện tại: **${userData.currentStamina}/${userData.maxStamina}**.`);
                    break;
                }
                case '03': { // Bùa Chặn Exp
                    const targetUserData = await getUserData(targetMember.id);
                    if (!targetUserData.hasStartedCultivation) {
                        await message.reply(`${targetMember.displayName} chưa bắt đầu con đường tu tiên!`, { flags: [64] });
                        userData[item.itemCountField] += quantity; // Refund
                        await updateUserData(userId, userData);
                        return;
                    }

                    const userRealmIndex = LEVELS.findIndex(l => l.level === userData.level);
                    const targetRealmIndex = LEVELS.findIndex(l => l.level === targetUserData.level);
                    const realmDifference = targetRealmIndex - userRealmIndex;

                    let extraCost = 0;
                    if(realmDifference === 1) extraCost = 5;
                    else if(realmDifference === 2) extraCost = 10;
                    else if(realmDifference === 3) extraCost = 20;
                    else if(realmDifference > 3) {
                         await message.reply('Đối phương có cảnh giới quá cao, bùa không thể ảnh hưởng.', { flags: [64] });
                         userData[item.itemCountField] += quantity; // Hoàn lại bùa
                         await updateUserData(userId, userData);
                         return;
                    }

                    if (userData.linhThach < extraCost) {
                        await message.reply(`Bạn không đủ Linh Thạch để sử dụng bùa lên mục tiêu này. Cần thêm ${extraCost} Linh Thạch.`, { flags: [64] });
                        userData[item.itemCountField] += quantity; // Hoàn lại bùa
                        await updateUserData(userId, userData);
                        return;
                    }

                    userData.linhThach -= extraCost;

                    for (let i = 0; i < quantity; i++) {
                        targetUserData.activeExpBlockTalismans.push({ endTime: now + item.durationMs });
                        if (targetUserData.level > 0) targetUserData.currentStamina = Math.max(0, targetUserData.currentStamina - 1); 
                    }
                    await updateUserData(targetMember.id, targetUserData);

                    if (message.deletable) await message.delete().catch(console.error);
                    await message.channel.send(`<@${message.author.id}> đã sử dụng **${quantity} ${item.name}** để tấn công <@${targetMember.id}>!`); 
                    break;
                }
                case '04': { // Bùa Giảm Tỉ Lệ Đột Phá
                    const targetUserData = await getUserData(targetMember.id);
                    if (!targetUserData.hasStartedCultivation) {
                        await message.reply(`${targetMember.displayName} chưa bắt đầu con đường tu tiên!`, { flags: [64] });
                        userData[item.itemCountField] += quantity; // Refund
                        await updateUserData(userId, userData);
                        return;
                    }
                    let appliedCount = 0;
                    for (let i = 0; i < quantity; i++) {
                        if (targetUserData.activeBreakthroughReduceTalismans.length < item.maxStacks) {
                            targetUserData.activeBreakthroughReduceTalismans.push({ endTime: now + item.durationMs });
                            appliedCount++;
                        }
                    }
                    const refundedCount = quantity - appliedCount;
                    userData[item.itemCountField] += refundedCount; // Hoàn lại số bùa không dùng được

                    if (appliedCount > 0) {
                        await updateUserData(targetMember.id, targetUserData);
                        if (message.deletable) await message.delete().catch(console.error);
                        await message.channel.send(`Dường như có một luồng năng lượng tà ác đang nhắm vào <@${targetMember.id}>, khiến cho việc đột phá trở nên khó khăn hơn!`); 
                        await targetMember.send(`Bạn đã dính **${appliedCount}** hiệu ứng xấu từ **${item.name}**! Tỉ lệ đột phá sẽ bị giảm trong 72 giờ.`).catch(() => {});
                    }
                    if(refundedCount > 0){
                         await message.channel.send({ content: `Không thể dùng thêm **${refundedCount} ${item.name}** lên <@${targetMember.id}> vì đã đạt số bùa tối đa.`, flags: [64] });
                    }
                    break;
                }
                case '06': { // Học Hấp Tinh Đại Pháp
                    if (quantity > 1) {
                         await message.reply('Mỗi lần chỉ có thể học 1 quyển công pháp.', { flags: [64] });
                         userData[item.itemCountField] += quantity; // Refund
                         await updateUserData(userId, userData);
                         return;
                    }
                    if (userData.learnedSkills.includes(item.skillName)) {
                        await message.reply('Bạn đã học công pháp này rồi.', { flags: [64] });
                        userData[item.itemCountField] += quantity; // Refund
                        return;
                    }
                    if (userData.maxStamina === 0 || userData.currentStamina < userData.maxStamina) {
                        await message.reply('Bạn cần đầy thể lực để học công pháp này. (Chỉ cảnh giới từ Luyện Khí trở lên mới có thể học)', { flags: [64] });
                        userData[item.itemCountField] += quantity; // Refund
                        return;
                    }

                    userData.learnedSkills.push(item.skillName);
                    userData.currentStamina = 0;
                    await message.reply(`Bạn đã dùng toàn bộ thể lực để học thành công **${item.name}**! Thể lực của bạn hiện tại là 0. Bạn có thể dùng lệnh \`!cp06 <@người_dùng>\` để thi triển.`);
                    break;
                }
            }
            await updateUserData(userId, userData);
            return;
        }

    }


    // --- XP and Currency Gain Logic for normal messages ---
    if (!userData.hasStartedCultivation) return; 

    if ((userData.punishedUntil && now < userData.punishedUntil) || userData.activeExpBlockTalismans.length > 0 || (userData.spamPunishedUntil && now < userData.spamPunishedUntil) || (userData.level > 0 && userData.currentStamina <= 0)) {
        if(userData.level > 0 && userData.currentStamina <= 0){
             const lastSent = staminaDepletedMessageSent.get(userId) || 0;
            if (now - lastSent > STAMINA_DEPLETED_MESSAGE_COOLDOWN_MS) {
                await message.reply('Thể lực của bạn đã cạn kiệt! Bạn không thể nhận Exp và Linh Thạch từ tin nhắn lúc này.').catch(()=>{});
                staminaDepletedMessageSent.set(userId, now); 
            }
        }
        return; 
    }

    const lastSenderInChannel = channelLastSender.get(message.channel.id);
    if (!isSpecialChannel && lastSenderInChannel === userId) {
        userData.consecutiveMessages = (userData.consecutiveMessages || 0) + 1;
        if (userData.consecutiveMessages > SPAM_MESSAGE_THRESHOLD) {
            const currentLevelXp = userData.xp;
            if (currentLevelXp > 0) {
                const xpLost = Math.floor(currentLevelXp / 2);
                userData.xp -= xpLost;
                userData.cumulativeXp = Math.max(0, userData.cumulativeXp - xpLost);

                await message.channel.send(`**Cảnh báo Thiên Đạo!** <@${userId}>: Do hành vi spam, bạn bị trừ **${xpLost} Exp**, kinh nghiệm cảnh giới hiện tại còn lại **${Math.floor(userData.xp)}**. Đồng thời bị cấm nhận Exp và Linh Thạch trong **30 phút**.`);
            }
            const punishmentDuration = 30 * 60 * 1000;
            userData.spamPunishedUntil = now + punishmentDuration;
            userData.consecutiveMessages = 0; 
        }
    } else {
        userData.consecutiveMessages = 0;
    }
    channelLastSender.set(message.channel.id, userId);

    if (message.content.length >= MIN_MESSAGE_LENGTH) {
        let effectiveMessageCooldown = MESSAGE_COOLDOWN_SECONDS;
        let xpMultiplier = 1;

        if (userData.activeBoost && now < userData.activeBoost.endTime) {
            effectiveMessageCooldown = userData.activeBoost.messageCooldownSeconds;
            xpMultiplier *= userData.activeBoost.xpMultiplier;
        }
        if (userData.songTuSkillActiveEndTime && now < userData.songTuSkillActiveEndTime) {
             xpMultiplier *= 2;
        }
        if (isSpecialChannel) {
            effectiveMessageCooldown = SPECIAL_CHANNEL_COOLDOWN_SECONDS;
            xpMultiplier *= SPECIAL_XP_MULTIPLIER;
        } else if (userData.level > 0 && userData.currentStamina <= (userData.maxStamina / 2)) {
            effectiveMessageCooldown = 180;
        }

        const timeSinceLastMessage = (now - (userLastMessageTime.get(userId) || 0)) / 1000;
        if (timeSinceLastMessage >= effectiveMessageCooldown) {
            userLastMessageTime.set(userId, now);

            const currentLevelConfig = getLevelConfig(userData.level);
            const messagesNeeded = currentLevelConfig ? currentLevelConfig.messagesNeededForXp : 1;

            userData.messagesSinceLastXPGain = (userData.messagesSinceLastXPGain || 0) + 1;

            if (userData.messagesSinceLastXPGain >= messagesNeeded) {
                const xpGain = 1 * xpMultiplier;
                userData.xp += xpGain;
                userData.cumulativeXp += xpGain;
                userData.messagesSinceLastXPGain = 0; 

                if (!isSpecialChannel && userData.level > 0) {
                    userData.xpSinceLastStaminaDeduct = (userData.xpSinceLastStaminaDeduct || 0) + xpGain;
                    if (userData.xpSinceLastStaminaDeduct >= 10) { 
                        userData.currentStamina = Math.max(0, userData.currentStamina - 1);
                        userData.xpSinceLastStaminaDeduct -= 10; 
                    }
                }

                // CƠ CHẾ MỚI: Logic kiểm tra đột phá
                const nextLevelConfig = getNextLevelConfig(userData.level);
                if (nextLevelConfig && userData.xp >= nextLevelConfig.xpNeeded) {
                    let actualBreakthroughChance = nextLevelConfig.breakthroughChance;

                    if(userData.activeBreakthroughReduceTalismans.length > 0){
                        const totalReduction = userData.activeBreakthroughReduceTalismans.length * SHOP_ITEMS['04'].reductionPercent;
                        actualBreakthroughChance = Math.max(0, nextLevelConfig.breakthroughChance - totalReduction);
                    }

                    if(Math.random() * 100 < actualBreakthroughChance){
                        const leftoverXp = userData.xp - nextLevelConfig.xpNeeded;
                        userData.level = nextLevelConfig.level;
                        userData.xp = leftoverXp;

                        message.channel.send(`Chúc mừng <@${userId}>! Bạn đã đột phá cảnh giới **${nextLevelConfig.name}**! 🎉`);

                        const newLevelConfigData = getLevelConfig(userData.level);
                        if (newLevelConfigData && newLevelConfigData.maxStamina > 0) {
                            userData.currentStamina = newLevelConfigData.maxStamina; 
                        }
                        if(message.member) await updateUserRole(message.member, userData.level);
                    } else {
                        const xpLost = Math.floor(userData.xp * 0.1);
                        userData.xp -= xpLost;
                        userData.cumulativeXp = Math.max(0, userData.cumulativeXp - xpLost);

                        message.channel.send(`**Thất bại đột phá!** <@${userId}>: Bạn đã đột phá cảnh giới **${nextLevelConfig.name}** thất bại và bị trừ **${xpLost} Exp**!`);
                    }
                }
            }
        }
    }

    let effectiveLinhThachCooldown = LS_GAIN_COOLDOWN_SECONDS;
    let linhThachMultiplier = 1;

    if(isSpecialChannel){
        effectiveLinhThachCooldown = SPECIAL_LS_COOLDOWN_SECONDS;
        linhThachMultiplier = SPECIAL_LS_MULTIPLIER;
    } else if (userData.level > 0 && userData.currentStamina <= (userData.maxStamina / 2)) {
        effectiveLinhThachCooldown = 300;
    }

    const timeSinceLastLinhThachGain = (now - userData.lastLinhThachGainTime) / 1000;
    if (timeSinceLastLinhThachGain >= effectiveLinhThachCooldown) {
        const dailyCap = getDailyLinhThachCap(userData.level);
        if (!isSpecialChannel && userData.dailyLinhThachGained >= dailyCap) {
             // Already at cap, do nothing
        } else {
            const lsGained = LS_PER_MESSAGE * linhThachMultiplier;
            userData.linhThach += lsGained;
            userData.lastLinhThachGainTime = now; 
            if (!isSpecialChannel) {
                userData.dailyLinhThachGained += lsGained;
            }
        }
    }

    await updateUserData(userId, userData);
});

// Voice channel XP gain (every minute)
setInterval(async () => {
    const now = Date.now();
    if (!client.replitAppId || !db) return;

    for (const [userId, joinTime] of userVoiceJoinTimes.entries()) {
        const guild = client.guilds.cache.first(); 
        if (!guild) continue;

        try {
            const member = await guild.members.fetch(userId);
            if (member && member.voice.channel && !member.user.bot) {
                let userData = await getUserData(userId);
                if (!userData || !userData.hasStartedCultivation) continue;

                const isUnderPunishment = userData.punishedUntil && now < userData.punishedUntil;
                const hasActiveExpBlock = userData.activeExpBlockTalismans.length > 0;

                if (isUnderPunishment || hasActiveExpBlock || (userData.level > 0 && userData.currentStamina <= 0)) {
                    continue; 
                }

                const minutesInVoice = (now - joinTime) / (60 * 1000);
                let xpGained = XP_PER_MINUTE_VOICE * minutesInVoice;

                let xpMultiplier = 1;
                if (userData.activeBoost && userData.activeBoost.type === SHOP_ITEMS['01'].name && now < userData.activeBoost.endTime) {
                    xpMultiplier *= userData.activeBoost.xpMultiplier;
                }
                if (userData.songTuSkillActiveEndTime && now < userData.songTuSkillActiveEndTime) {
                    xpMultiplier *= 2;
                }
                xpGained *= xpMultiplier;

                userData.xp += xpGained;
                userData.cumulativeXp += xpGained;
                userData.lastActivityTime = now; 

                const nextLevelConfig = getNextLevelConfig(userData.level);
                if (nextLevelConfig && userData.xp >= nextLevelConfig.xpNeeded) {
                    let actualBreakthroughChance = nextLevelConfig.breakthroughChance;

                    if (userData.activeBreakthroughReduceTalismans.length > 0) {
                        const totalReduction = userData.activeBreakthroughReduceTalismans.length * SHOP_ITEMS['04'].reductionPercent;
                        actualBreakthroughChance = Math.max(0, nextLevelConfig.breakthroughChance - totalReduction);
                    }

                    if (Math.random() * 100 < actualBreakthroughChance) {
                        const leftoverXp = userData.xp - nextLevelConfig.xpNeeded;
                        userData.level = nextLevelConfig.level;
                        userData.xp = leftoverXp;

                        member.send(`Chúc mừng! Bạn đã đột phá cảnh giới **${nextLevelConfig.name}** trong kênh thoại! 🎉`).catch(e=>console.log("Không thể DM cho người dùng."));

                        const newLevelConfigData = getLevelConfig(userData.level);
                        if (newLevelConfigData && newLevelConfigData.maxStamina > 0) {
                            userData.currentStamina = newLevelConfigData.maxStamina; 
                        }
                        await updateUserRole(member, userData.level);
                    } else {
                        const xpLost = Math.floor(userData.xp * 0.1);
                        userData.xp -= xpLost;
                        userData.cumulativeXp = Math.max(0, userData.cumulativeXp - xpLost);
                        member.send(`**Thất bại đột phá!** Bạn đã đột phá cảnh giới **${nextLevelConfig.name}** thất bại trong kênh thoại và bị trừ **${xpLost} Exp**!`).catch(e=>console.log("Không thể DM cho người dùng."));
                    }
                }
                await updateUserData(userId, userData);
                userVoiceJoinTimes.set(userId, now); 
            }
        } catch (error) {
            if (error.code !== 10007) { // Unknown Member
               console.error(`Lỗi khi xử lý XP thoại cho ${userId}:`, error);
            }
        }
    }
}, 60 * 1000); 

async function performDailyReset() {
    console.log(`[DAILY RESET] Bắt đầu quá trình reset dữ liệu hàng ngày...`);
    const usersCollectionRef = collection(db, `artifacts/${client.replitAppId}/public/data/discordBotLevels`);
    const querySnapshot = await getDocs(usersCollectionRef);
    const batch = writeBatch(db);
    let count = 0;

    querySnapshot.forEach(docSnap => {
        const data = docSnap.data();
        if (data.hasStartedCultivation) {
            const levelConfig = getLevelConfig(data.level || 0);
            const maxStamina = levelConfig ? levelConfig.maxStamina : 0;

            const updateData = {
                dailyLinhThachGained: 0,
                dailyDanX2ExpPurchases: 0,
                dailyDanX2ExpUses: 0,
                dailyBuaChanExpUses: 0,
                songTuSkillDailyUseCount: 0,
                currentStamina: maxStamina
            };
            batch.update(docSnap.ref, updateData);
            count++;
        }
    });

    await batch.commit();
    console.log(`[DAILY RESET] Đã reset thành công dữ liệu hàng ngày và hồi đầy thể lực cho ${count} người chơi!`);
}

function runDailyTasks() {
    let lastResetDate = new Date().toLocaleDateString('en-CA', { timeZone: 'Asia/Ho_Chi_Minh' });

    setInterval(async () => {
        const currentDate = new Date().toLocaleDateString('en-CA', { timeZone: 'Asia/Ho_Chi_Minh' });
        if (currentDate !== lastResetDate) {
            await performDailyReset();
            lastResetDate = currentDate;
        }
    }, 60 * 1000 * 5); // Kiểm tra mỗi 5 phút
}

async function runInactivityCheck() {
    setInterval(async () => {
        console.log("[INACTIVITY CHECK] Bắt đầu kiểm tra người chơi không hoạt động...");
        const allUsers = await getAllUserData(true); // Lấy toàn bộ dữ liệu
        const now = Date.now();
        const batch = writeBatch(db);
        let penalizedCount = 0;

        for (const userData of allUsers) {
            if (userData.lastActivityTime && !userData.inactivityNotified && (now - userData.lastActivityTime > INACTIVITY_RESET_PERIOD_MS)) {
                 const currentLevelXp = userData.xp || 0;
                 if (currentLevelXp > 0) {
                    const xpLost = Math.ceil(currentLevelXp / 2);
                    const newXp = userData.xp - xpLost;
                    const newCumulativeXp = Math.max(0, (userData.cumulativeXp || 0) - xpLost);

                    const userDocRef = doc(db, `artifacts/${client.replitAppId}/public/data/discordBotLevels`, userData.discordId);
                    batch.update(userDocRef, { 
                        xp: newXp,
                        cumulativeXp: newCumulativeXp,
                        inactivityNotified: true // Đánh dấu đã phạt để không phạt lại
                    });
                    penalizedCount++;
                    console.log(`Người dùng ${userData.discordId} bị phạt vì không hoạt động, trừ ${xpLost} Exp.`);
                 }
            }
        }

        if (penalizedCount > 0) {
            await batch.commit();
            console.log(`[INACTIVITY CHECK] Đã xử lý phạt ${penalizedCount} người chơi.`);
        } else {
            console.log("[INACTIVITY CHECK] Không có người chơi nào bị phạt.");
        }
    }, 60 * 60 * 1000); // Kiểm tra mỗi giờ
}

client.on('voiceStateUpdate', (oldState, newState) => {
    const userId = newState.member.id;

    if (!oldState.channelId && newState.channelId) {
        userVoiceJoinTimes.set(userId, Date.now());
        console.log(`${newState.member.user.tag} đã tham gia kênh thoại: ${newState.channel.name}`);
    } 
    else if (oldState.channelId && !newState.channelId) {
        if (userVoiceJoinTimes.has(userId)) {
            userVoiceJoinTimes.delete(userId);
            console.log(`${newState.member.user.tag} đã rời kênh thoại.`);
        }
    }
});


// Đăng nhập bot
client.login(process.env.DISCORD_BOT_TOKEN);
